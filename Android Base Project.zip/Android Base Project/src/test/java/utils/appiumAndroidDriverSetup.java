package utils;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class appiumAndroidDriverSetup {
	public static  AppiumDriver<MobileElement> driver;
	public static void setUpDriver(){
		DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceName", "Samsung");
        //caps.setCapability("udid", "04157df8a3b40d"); 
		caps.setCapability("udid", "04157df8a3b40d"); //Give Device ID of your locally connected andoird mobile device
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "6.0");
        caps.setCapability("appPackage", "com.citi.citimobile.uat");
        caps.setCapability("appActivity", "com.citi.mobile.pt3.GlobalPhoneActivity");
        caps.setCapability("noReset", "true");
        //Instantiate Appium Driver
        try {
                     //AppiumDriver<MobileElement> driver = new AndroidDriver<MobileElement>(new URL("http://osxgcbot164:4723/wd/hub"), caps);
					 AppiumDriver<MobileElement> driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                      driver.manage().timeouts().implicitlyWait(45, TimeUnit.SECONDS);
                     appiumAndroidDriverSetup.driver=driver;
        }
        catch (MalformedURLException e) {
               //System.out.println(e.getMessage());
               e.getCause().printStackTrace();
        }            
	}
	public static AppiumDriver<MobileElement> getDriver() {
		return driver;
	}
	public static void tearDown() {
		 
        if (((AppiumDriver)driver) != null) {
            try {
            	((AppiumDriver)driver).closeApp(); // Close the app which was provided in the capabilities at session creation
            	((AppiumDriver)driver).quit(); // quits the session created between the client and the server
			} catch (Exception e) {
				e.printStackTrace();
			}
         driver = null;
        }
    }
	public static void quit() {
		// TODO Auto-generated method stub
		
	}
}