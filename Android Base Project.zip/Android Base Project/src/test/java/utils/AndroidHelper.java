package utils;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;


public class AndroidHelper {
	
	public static String reportNameFinal;
	public static String reportFolderNameFinal;
	
	public static List<String[]> scenarioList = new ArrayList<String[]>();
	
	final static Log log = LogFactory.getLog(AndroidHelper.class.getName());
    
    public static void takeScreenshot(){
    	takeScreenshot("");
    	
    }
    
    public static void takeScreenshot(String imageName){
    	try {
			Thread.sleep(1000);
			
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	File scrFile = ((TakesScreenshot)appiumAndroidDriverSetup.getDriver()).getScreenshotAs(OutputType.FILE);
	    try {
	    	SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy_hhmmss");
			Date curDate = new Date();
			String imagePath;
			
			if(System.getProperty("os.name").contains("Windows")){
				String strDate = sdf.format(curDate);
		    	imagePath = System.getProperty("reportFolderNameFinal") + "/" + imageName +  "_" + strDate + ".png";
			}
			else
			{
				String strDate = sdf.format(curDate);
		    	imagePath =  System.getProperty("reportFolderNameFinal")  + "/" + imageName +".png";
			}
			
	    	FileUtils.copyFile(scrFile, new File(imagePath));
	    	
	    	
	    	Reporter.addScreenCaptureFromPath(imagePath);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
    	
    }
    
    public static void setupExtentReport(){
    	ConfigFileReader configFileReader;
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy_hhmmss");
		Date curDate = new Date();
		String strDate = sdf.format(curDate);
		String fileName;
		configFileReader= new ConfigFileReader();
		if(System.getProperty("os.name").contains("Windows")){
			fileName = System.getProperty("user.dir")+configFileReader.getReportPath()+ strDate + "/"+ strDate +".html";
			reportNameFinal =fileName;
			reportFolderNameFinal = System.getProperty("user.dir")+configFileReader.getReportPath()+ strDate;
			}
		else
		{
			fileName = System.getProperty("user.dir")+"/Results.html";
			reportNameFinal =fileName;
			reportFolderNameFinal = System.getProperty("user.dir")+configFileReader.getReportPath()+ strDate;
		}
		
		System.setProperty("reportFolderNameFinal", reportFolderNameFinal);
		ExtentProperties extentProperties = ExtentProperties.INSTANCE;
		extentProperties.setReportPath(fileName);
    }
    
    public static void tearDownReport() throws Exception{
    	try{
    	Reporter.loadXMLConfig(new File("src/test/resources/extent-config.xml"));
        Reporter.setSystemInfo("user", System.getProperty("user.name"));
        Reporter.setSystemInfo("os", System.getProperty("os.name"));
        Reporter.setSystemInfo("java version", System.getProperty("java.version"));
        
        //Capabilities capa = ((RemoteWebDriver)appiumiOSDriverSetup.getDriver()).getCapabilities();
        //Reporter.setSystemInfo("browser", capa.getBrowserName());        
        Reporter.setSystemInfo("os", System.getProperty("os.name"));
        //Reporter.setTestRunnerOutput(capa.toString());
        Reporter.setTestRunnerOutput("[~~~~~~~~~~~~]" );
    	}
    	catch(Exception e){
    		e.printStackTrace();	
    	}

    }
    
    public static void updateALM() throws Exception{
    	for (String[] scenRow : AndroidHelper.scenarioList) {
			 //AlmRest almRest = new AlmRest();			 
			//almRest.updateResult(scenRow[0],scenRow[1],SeleniumHelper.reportFolderNameFinal);
			
		   
		    } 
    	

    }
    
    
    
}
