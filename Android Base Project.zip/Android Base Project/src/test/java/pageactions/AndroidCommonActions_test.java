package pageactions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utils.appiumAndroidDriverSetup;


public class AndroidCommonActions_test {

	public AndroidCommonActions_test() {
		// TODO Auto-generated constructor stub
	}

	public void androidPerformClick(final WebElement e) {
		Actions action = new Actions(appiumAndroidDriverSetup.driver);
		try {
			action.click(e).perform();
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public boolean androidisElementPresent(final WebElement e) {
		try {
			return e.isDisplayed();
		} catch (Exception exc) {
			exc.printStackTrace();
			return false;
		}

	}
}
