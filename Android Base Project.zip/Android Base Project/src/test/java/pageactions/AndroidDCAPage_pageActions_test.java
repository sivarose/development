package pageactions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import pagelocators.AndroidDCAPage_pageLocators_test;
import pagelocators.AndroidMobilePostLogin_pageLocators_test;
import utils.appiumAndroidDriverSetup;

public class AndroidDCAPage_pageActions_test {

	AndroidMobilePostLogin_pageLocators_test androidPostLoginPageLocators = null;
	AndroidDCAPage_pageLocators_test androidDCAPageLocators = null;
	
	public AndroidDCAPage_pageActions_test() {
		this.androidPostLoginPageLocators= new AndroidMobilePostLogin_pageLocators_test();
    	this.androidDCAPageLocators = new AndroidDCAPage_pageLocators_test();
    	PageFactory.initElements(appiumAndroidDriverSetup.getDriver(), androidPostLoginPageLocators);
    	PageFactory.initElements(appiumAndroidDriverSetup.getDriver(), androidDCAPageLocators);
	}

	public void ClickSubMenuActivateATMDebitCard(){
		androidDCAPageLocators.SubMenuActivateATMDebitCard.get(0).click();				
	}
	
	public void ClickAcvtivateButton(){
		((WebElement) androidDCAPageLocators.ActivateButton).click();	
	}
	
	public void mfaEnterSecurityQuestionsAndAnswers(){
		String security_question1 = androidDCAPageLocators.mfaSecurityQuestions.get(0).getText();
		String security_question2 = androidDCAPageLocators.mfaSecurityQuestions.get(1).getText();

		String securiy_answer1 = security_question1.substring(security_question1.lastIndexOf(" ")+1);
		String securiy_answer2 = security_question2.substring(security_question2.lastIndexOf(" ")+1);	
		
		securiy_answer1 = securiy_answer1.substring(0, securiy_answer1.length() - 1);
		securiy_answer2 = securiy_answer2.substring(0, securiy_answer2.length() - 1);
		
		androidDCAPageLocators.mfaSecurityAnswers.get(0).sendKeys(securiy_answer1);
		androidDCAPageLocators.mfaSecurityAnswers.get(1).sendKeys(securiy_answer2);
		androidDCAPageLocators.mfaSecurityQuestionsSubmitButtion.click();
		androidDCAPageLocators.doneButtonDcaConfirmationScreen.click();
	}
	
	public void validateDcaAlertActivationContent(){
		try{
			if(androidPostLoginPageLocators.dcaDashboardAlertActivationOverlayContent.isDisplayed()){
				System.out.println(androidPostLoginPageLocators.dcaDashboardAlertActivationOverlayContent.getText());
			}
		}
		catch(Exception noElementFound){
			System.out.println(noElementFound);			
		}
	}
}
