package pageactions;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import pageactions.AndroidCommonActions_test;
import pagelocators.AndroidMobileHomePage_pageLocators_test;
import pagelocators.AndroidMobilePostLogin_pageLocators_test;
import utils.appiumAndroidDriverSetup;

public class AndroidMobileLoginPage_pageActions_test  {

	AndroidMobileHomePage_pageLocators_test androidHomePageLocators = null;
	AndroidMobilePostLogin_pageLocators_test androidPostLoginPageLocators = null;
	AndroidCommonActions_test androidCommonActions = new AndroidCommonActions_test();
	
	
    public AndroidMobileLoginPage_pageActions_test(){
    	this.androidHomePageLocators = new AndroidMobileHomePage_pageLocators_test();
    	this.androidPostLoginPageLocators= new AndroidMobilePostLogin_pageLocators_test(); 
        PageFactory.initElements(appiumAndroidDriverSetup.getDriver(), androidHomePageLocators);
        PageFactory.initElements(appiumAndroidDriverSetup.getDriver(), androidPostLoginPageLocators);
    }
	
	public void mobileThickAndroidSingOn(String inputUserId, String inputPassword){
		androidHomePageLocators.mobileThickAndroidSignOnInputBox.clear();
		androidHomePageLocators.mobileThickAndroidSignOnInputBox.sendKeys(inputUserId);
		androidHomePageLocators.mobileThickAndroidPassWordInputBox.sendKeys(inputPassword);
		appiumAndroidDriverSetup.driver.navigate().back();
		androidHomePageLocators.mobileThickAndroidSignOnButton.click();
		
		if(androidCommonActions.androidisElementPresent(androidHomePageLocators.mobileThickAndroidAnyInter)) {
			androidHomePageLocators.mobileThickAndroidAnyInter.click();	
		}
		
	}
	

	
	public void mobileThickAndroidSingOn1(String inputUserId, String inputPassword){
		String tempValue = androidHomePageLocators.mobileThickAndroidSignOnInputBox.getText();
		if( tempValue.equalsIgnoreCase("User ID") ){
		}
		else {
			//Deleting exisiting user id
			/*int tempCounter = 1;
				for(tempCounter= 1;tempCounter<20;tempCounter++) {
				mobileThickAndroidSignOnInputBox.sendKeys(Keys.DELETE);
				}*/	
		}
		androidHomePageLocators.mobileThickAndroidSignOnInputBox.sendKeys(Keys.DELETE);
		androidHomePageLocators.mobileThickAndroidSignOnInputBox.sendKeys(inputUserId);
		androidHomePageLocators.mobileThickAndroidPassWordInputBox.sendKeys(inputPassword);		
		appiumAndroidDriverSetup.driver.navigate().back();		
		androidHomePageLocators.mobileThickAndroidSignOnButton.click();
	}
	
	
}
