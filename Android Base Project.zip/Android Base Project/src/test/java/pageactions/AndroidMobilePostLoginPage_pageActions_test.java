package pageactions;

import static org.testng.Assert.assertTrue;
import io.appium.java_client.MobileBy;

import org.openqa.selenium.support.PageFactory;

import pageactions.AndroidCommonActions_test;
import pagelocators.AndroidDCAPage_pageLocators_test;
import pagelocators.AndroidMobileHomePage_pageLocators_test;
import pagelocators.AndroidMobilePostLogin_pageLocators_test;
import stepDef.AfterActions;
import stepDef.BeforeActions;
import utils.appiumAndroidDriverSetup;

public class AndroidMobilePostLoginPage_pageActions_test  {

	AndroidMobileHomePage_pageLocators_test androidHomePageLocators = null;
	AndroidMobilePostLogin_pageLocators_test androidPostLoginPageLocators = null;
	AndroidCommonActions_test androidCommonActions = null;
	
    public AndroidMobilePostLoginPage_pageActions_test(){
    	this.androidPostLoginPageLocators= new AndroidMobilePostLogin_pageLocators_test();
    	this.androidHomePageLocators = new AndroidMobileHomePage_pageLocators_test();
    	this.androidCommonActions = new AndroidCommonActions_test();
    	PageFactory.initElements(appiumAndroidDriverSetup.getDriver(), androidPostLoginPageLocators);
    	PageFactory.initElements(appiumAndroidDriverSetup.getDriver(), androidHomePageLocators);
    }
    
	public void VerifyOnDcaDashboardAlert(){
		try{
			if(androidPostLoginPageLocators.dcaDashboardAlertWebElement.isDisplayed()){									
			}
		}
		catch(Exception noElementFound){
			System.out.println(noElementFound);			
		}		
	}
	
	public void clickOpenNavigationMenu(){	
		appiumAndroidDriverSetup.driver.findElement(MobileBy.AccessibilityId("Navigate up")).click();		
	}
	
	
	public void validateDashboard(){
		
			if(androidCommonActions.androidisElementPresent(androidPostLoginPageLocators.mobileDashboardChkAccounts) ){
				System.out.println("CHK Account Displayed");
				assertTrue(true);
			} else if (androidCommonActions.androidisElementPresent(androidPostLoginPageLocators.mobileDashboardCardAccounts)){
				System.out.println("CARD Account Displayed");
				assertTrue(true);
			}
			else{
				assertTrue(false);
			}
		
	}

	public void mobileThickAndroidSignOff(){
		
		if(androidHomePageLocators.mobileThickAndroidAnyInter.isDisplayed()) {
			androidHomePageLocators.mobileThickAndroidAnyInter.click();	
		}
		androidPostLoginPageLocators.mobileThickAndroidSignOffButtonInNavigationMenu.click();
		androidPostLoginPageLocators.mobileThickAndroidSignOffButton.click();
		androidPostLoginPageLocators.mobileThickAndroidSignOffButton1.click();
	}
	
}
