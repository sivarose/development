package pagelocators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class AndroidMobilePostLogin_pageLocators_test  {

	@FindBy(id="com.citi.citimobile.uat:id/signOnButtonId")
	public WebElement mobileThickAndroidSignOffButtonInNavigationMenu;
	
	@FindBy(id="com.citi.citimobile.uat:id/btn_session_signoff")
	public WebElement mobileThickAndroidSignOffButton;
	
	@FindBy(id="com.citi.citimobile.uat:id/picker_cancel")
	public WebElement mobileThickAndroidSignOffButton1;
	
	
	 //Find mobile elements 
	 @FindBy(id="com.citi.citimobile.uat:id/checking_accounts_header_wrapper")
	public WebElement AndroidDashboard;
	 
	@FindBy(id="com.citi.citimobile.uat:id/alert_summary")
	public WebElement dcaDashboardAlertWebElement;
	
	@FindBy(id="com.citi.citimobile.uat:id/alert_dismiss")
	public WebElement dcaDashboardAlertOverlayOkButton;
	
	@FindBy(id="com.citi.citimobile.uat:id/account_uuid")
	public WebElement dcaDashboardAlertActivationOverlayContent;
	
	@FindBy(id="//*[@class='android.widget.ImageButton' and @index='0']")
	public WebElement dcaDashboardMenuButton;
	
	@FindBy(id="com.citi.citimobile.uat:id/checking_account_classification")
	public WebElement mobileDashboardChkAccounts;
	
	@FindBy(id="com.citi.citimobile.uat:id/credit_account_classification")
	public WebElement mobileDashboardCardAccounts;
}
