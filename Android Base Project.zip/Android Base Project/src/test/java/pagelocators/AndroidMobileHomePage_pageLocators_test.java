
package pagelocators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AndroidMobileHomePage_pageLocators_test{

	/*
	@FindBy(id="username")
	public WebElement mobileThickAndroidSignOnInputBox;
	
	@FindBy(id="password")
	public WebElement mobileThickAndroidPassWordInputBox;
	
	@FindBy(id="signonbutton")
	public WebElement mobileThickAndroidSignOnButton;
	*/

	@FindBy(id="com.citi.citimobile.uat:id/sign_on_userId_editText")
	public WebElement mobileThickAndroidSignOnInputBox;
	
	@FindBy(id="com.citi.citimobile.uat:id/passWord_editText")
	public WebElement mobileThickAndroidPassWordInputBox;
	
	@FindBy(id="com.citi.citimobile.uat:id/sign_on_Button")
	public WebElement mobileThickAndroidSignOnButton;

	@FindBy(id="android.widget.ImageButton")
	public WebElement mobileThickAndroidAnyInter;
	
	@FindBy(id="com.citi.citimobile.uat:id/credit_account_classification")
	public WebElement mobileDashboardAccounts;
	
	
}
