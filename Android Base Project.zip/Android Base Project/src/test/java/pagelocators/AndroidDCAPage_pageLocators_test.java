package pagelocators;

import io.appium.java_client.pagefactory.AndroidFindBy;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AndroidDCAPage_pageLocators_test {

	@AndroidFindBy(accessibility="Navigate up")
	public WebElement dashboardNavigationMenu;
	
	@FindBy(id="com.citi.citimobile.uat:id/iv_gnm_submenu_arrow")
	public List <WebElement> SubMenuManageYourCards;
	
	@FindBy(id="com.citi.citimobile.uat:id/gnm_item_label")
	public List <WebElement> SubMenuActivateATMDebitCard;
	
	@FindBy(xpath="//*[@text='Activate ATM/Debit Card']")
	public WebElement mnuActivateCard;
	
	@FindBy(id="com.citi.citimobile.uat:id/dca_btn_activate_now")
	public WebElement ActivateButton;
	
	@FindBy(id="com.citi.citimobile.uat:id/questionId")
	public List <WebElement> mfaSecurityQuestions;
	
	@FindBy(id="com.citi.citimobile.uat:id/enterAnswerTextId")
	public List <WebElement> mfaSecurityAnswers;
	
	@FindBy(id="com.citi.citimobile.uat:id/submitButtonId")
	public WebElement mfaSecurityQuestionsSubmitButtion;
	
	@FindBy(id="com.citi.citimobile.uat:id/dca_btn_done")
	public WebElement doneButtonDcaConfirmationScreen;
	
}
