package stepDef;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import utils.AndroidHelper;
import utils.ExcelUtils;
import utils.AndroidHelper;
import utils.appiumAndroidDriverSetup;


public class AfterActions {

    @After
    public static void tearDown(Scenario scenario) {
    	System.out.println(">> End of the transaction");
    	final Log log = LogFactory.getLog(AfterActions.class.getName());
    	
    	
			System.out.println("Android initialized");
			AppiumDriver<MobileElement> driver=appiumAndroidDriverSetup.getDriver();
			log.info(scenario.isFailed());
	    	 if (scenario.isFailed()) {
			    		 byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			             scenario.embed(screenshotBytes, "image/png");
			             AndroidHelper.takeScreenshot("AndroidFinal_Fasled");
			    		 }        
	    	 else
	    	 {
		    	 byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		         scenario.embed(screenshotBytes, "image/png");
		         AndroidHelper.takeScreenshot("AndroidFinal_Passed");
		   	 }
	    	 
	         appiumAndroidDriverSetup.tearDown();
	
    	
        ExcelUtils objExcelFile = new ExcelUtils();
        String filePath = System.getProperty("xlFile");
        System.out.println(" Data - "+ System.getProperty("Data"));
        objExcelFile.CreateExlFile(filePath);
        objExcelFile.writeExlFile(scenario.getName(), scenario.getStatus(), scenario.isFailed(),  filePath);

        
        
        appiumAndroidDriverSetup.quit();
    		log.info("------------------");   
    }
}  
