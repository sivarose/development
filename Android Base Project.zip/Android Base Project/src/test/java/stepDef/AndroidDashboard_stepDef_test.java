package stepDef;

import pageactions.AndroidDCAPage_pageActions_test;
import pageactions.AndroidMobileLoginPage_pageActions_test;
import pageactions.AndroidMobilePostLoginPage_pageActions_test;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AndroidDashboard_stepDef_test {
	AndroidMobileLoginPage_pageActions_test androidLoginActions = new AndroidMobileLoginPage_pageActions_test();
	AndroidMobilePostLoginPage_pageActions_test androidPostLoginActions = new AndroidMobilePostLoginPage_pageActions_test();
	AndroidDCAPage_pageActions_test androidDCAPafeActions = new AndroidDCAPage_pageActions_test();
	
	@Given("^Login into CBOL with credentials \"([^\"]*)\" and \"([^\"]*)\"$")
	public void login_into_CBOL_with_credentials_and(String inputUserId, String inputPassword) {
		//BeforeActions.setUp();
		androidLoginActions.mobileThickAndroidSingOn(inputUserId, inputPassword);		    
	}
	
	@Then("^I verify Dashboard$")
	public void validate_Dashboard_page() {
		androidPostLoginActions.validateDashboard();
	}

	@Then("^Sign Off the App$")
	public void signOff_App() {		
		//androidPostLoginActions.mobileThickAndroidSignOff();
	}
	
}
