package stepDef;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;


import cucumber.api.Scenario;
import cucumber.api.java.Before;
import utils.appiumAndroidDriverSetup;

public class BeforeActions {
	@Before
    public static void setUp(Scenario scen) {
		//final Log log = LogFactory.getLog(BeforeActions.class.getName());
		//ExtentCucumberFormatter.initiateExtentCucumberFormatter();
    	//log.info("Before");
		
		/*System.out.println("Android initialized");
		appiumAndroidDriverSetup.setUpDriver();
		System.out.println("Android End");*/
		
		/*System.out.println("iOS driver initialized.");
		appiumiOSDriverSetup.iOSappiumDriver();
		System.out.println("iOS driver End");
		*/
	
			System.out.println("Android initialized");
			appiumAndroidDriverSetup.setUpDriver();
			System.out.println("Android End");
	
		
        //log.info("Before1");
    }
}
