package runners;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

import utils.AndroidHelper;
import utils.FeatureOverride;
import utils.ConfigFileReader;

import com.cucumber.listener.ExtentCucumberFormatter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(
		 plugin = {"json:target/cucumber1.json", "pretty", "html:target/cucumber.html", "com.cucumber.listener.ExtentCucumberFormatter:./newreport.html"},
	        features = "src/test/resources/FeatureFiles",
        glue = "stepDef",
       //tags = {"@Hourly"}
        tags={"@Test"}
        ,monochrome = true
        )
public class AndroidRunner_test extends AbstractTestNGCucumberTests
{
	public static String fileNameFinal = "Default"; 
	ConfigFileReader configFileReader;
	  
	@BeforeClass
    public static void setup() {
		ConfigFileReader configFileReader;
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy_hhmmss");
		Date curDate = new Date();
		String strDate = sdf.format(curDate);
		
		configFileReader= new ConfigFileReader();
		System.out.println(System.getProperty("user.dir"));		
		String fileName = System.getProperty("user.dir")+"/"+strDate+".html";
		System.out.println(fileName);
		fileNameFinal =fileName;

		AndroidHelper.setupExtentReport();
		
		String xlfileName = System.getProperty("user.dir")+"/"+strDate+".xls";
		fileNameFinal =xlfileName;
		System.out.println("Current excel path is ="+ xlfileName);
		File newFile1 = new File(xlfileName);
		System.setProperty("xlFile", xlfileName);
		
    	System.setProperty("lgcag", "");

    	
    }
	

	@AfterClass
	public void afterClass() throws Exception {
		AndroidHelper.tearDownReport();
	}
	
	@AfterSuite
	public void afterSuite() throws Exception{
		//SeleniumHelper.updateALM();
       //LocalProxyServer.stop();
	}

	@BeforeSuite
	public void beforeSuite() {
		
		try {
			FeatureOverride.overrideFeatureFiles("src/test/resources/FeatureFiles");
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

