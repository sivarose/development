package xmlparse;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.*;

public class Saxparseeg extends DefaultHandler{
	
		
	boolean name = false;
	boolean standard = false;
	boolean gender = false;
	boolean mark1 = false;
	boolean mark2 = false;
	boolean address = false;
	
	public void startDocument() {
		System.out.println("Document starts here");		
	}
	
	public void startElement(String uri, String localName, String qName, Attributes attr) {		
		
	
		if(qName.contentEquals("student")) {
			System.out.println("Student id is :"+ attr.getValue("id"));
			
		}else if(qName.contentEquals("name")) {
			name=true;
		}else if(qName.contentEquals("standard")) {
			standard=true;
		}else if(qName.contentEquals("gender")) {
			gender=true;
		}else if(qName.contentEquals("mark1")) {
			mark1=true;
		}else if(qName.contentEquals("mark2")) {
			mark2=true;
		}else if(qName.contentEquals("address")) {
			address=true;
		}
	}
	
	public void characters(char ch[], int start, int len) {
		
		String data = new String(ch,start,len);
		
		if(name) {
		System.out.println("Name is :"+data);
		name=false;
		}else if(standard) {
			System.out.println("Standard is :"+data);
			standard=false;

		}else if(gender) {
			System.out.println("Gender is :"+data);
			gender=false;

		}else if(mark1) {
			System.out.println("Mark1 is :"+data);
			mark1=false;

		}else if(mark2) {
			System.out.println("Mark2 is :"+data);
			mark2=false;
		}else if(address) {
			System.out.println("Address is :"+data);
			address=false;
		}
	}		
	
public void endElement(String uri, String localName, String qName) {
						
		if(qName.equalsIgnoreCase("student")) {
			System.out.println("-----------------------");
		}		
	}  
		
	public void endDocument() {
		System.out.println("Document ends here");		
	}
			
	public static void main(String[] args) throws ParserConfigurationException, SAXException, FileNotFoundException, IOException {
		
		SAXParser sp = SAXParserFactory.newInstance().newSAXParser();
		sp.parse(new FileInputStream("C:\\Users\\Sivaranjani Gopal\\eclipse-workspace2\\JavaProgramming\\src\\xmlparse\\student.xml"),new Saxparseeg());
	}

}




