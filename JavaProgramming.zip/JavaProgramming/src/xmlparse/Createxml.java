package xmlparse;

import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Createxml {
	
	public static void main(String[] args)throws Exception {
		
		DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
		DocumentBuilder parser = df.newDocumentBuilder();
		
		
		Document doc = parser.newDocument();
		
		Element root = doc.createElement("Employees");
		
		doc.appendChild(root);
		
		Element emp = doc.createElement("employee");
		
		root.appendChild(emp);
				
		Element emp_id = doc.createElement("employeeid");
		
		emp.appendChild(emp_id);
		
		Element name = doc.createElement("name");
		
		emp.appendChild(name);
		
		Element dept = doc.createElement("dept");
		
		emp.appendChild(dept);
				
		Text empid_value = doc.createTextNode("1036323");
		
		Text name_value = doc.createTextNode("Sivaranjani");
			
		Text dept_value = doc.createTextNode("csc");
	
		emp_id.appendChild(empid_value);
		name.appendChild(name_value);
		dept.appendChild(dept_value);
		
		FileOutputStream fout = new FileOutputStream("C:\\Users\\Sivaranjani Gopal\\eclipse-workspace2\\JavaProgramming\\src\\xmlparse\\student.xml");
		
		TransformerFactory tfac = TransformerFactory.newInstance();
		
		Transformer tf = tfac.newTransformer();
		
		tf.transform(new DOMSource(doc), new StreamResult(fout));
		
		System.out.println("XML file is created successfully");
		
	}
}
