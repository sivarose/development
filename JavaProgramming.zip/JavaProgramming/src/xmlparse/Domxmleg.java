package xmlparse;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class Domxmleg {
	
public static void main(String[] args)throws Exception{
	
	File f1 = new File("C:\\Users\\Sivaranjani Gopal\\eclipse-workspace2\\JavaProgramming\\src\\xmlparse\\student.xml");
	
	DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
	
	DocumentBuilder b =df.newDocumentBuilder();
	
	Document doc = b.parse(f1);
	
	System.out.println("Root element is "+doc.getDocumentElement().getNodeName());

	NodeList nl = doc.getElementsByTagName("student");
	
	System.out.println("Lenght of the list is: "+nl.getLength());
	
	for(int i=0; i< nl.getLength();i++) {
		
		Node n = nl.item(i);
		System.out.println("Current element is"+n.getNodeName());
		
		Element e = (Element) n;
	System.out.println("Student id is :"+e.getAttribute("id"));
	
	System.out.println("Student name is "+e.getElementsByTagName("name").item(0).getTextContent());		

	System.out.println("Student std is "+e.getElementsByTagName("std").item(0).getTextContent());		
	
	System.out.println("Student gender is "+e.getElementsByTagName("gender").item(0).getTextContent());		

	System.out.println("Student mark1 is "+e.getElementsByTagName("mark1").item(0).getTextContent());		

	System.out.println("Student mark2 is "+e.getElementsByTagName("mark2").item(0).getTextContent());		
	
	System.out.println("Student address is "+e.getElementsByTagName("address").item(0).getTextContent());		
	
		
	}
	
}	
}
