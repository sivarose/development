package xmlparse;
import java.io.FileOutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Crtxml {
	
	public static void main(String[] args)throws Exception{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder parser = factory.newDocumentBuilder();
		
		/*create a new Document */
		Document doc = parser.newDocument();
		
		/*create root element */
		Element root = doc.createElement("students");
		doc.appendChild(root);
		
		Element stud = doc.createElement("student");
		root.appendChild(stud);
		
		
		Element admno = doc.createElement("admno");
		stud.appendChild(admno);
		Element name = doc.createElement("name");
		stud.appendChild(name);
		Element email = doc.createElement("email");
		stud.appendChild(email);	
		
		Text admno_data = doc.createTextNode("1001");
		Text name_data = doc.createTextNode("Sunil Joseph");
		Text email_data = doc.createTextNode("sunil@hotmail.com");
		
		name.appendChild(name_data);
		admno.appendChild(admno_data);
		email.appendChild(email_data);
				
		FileOutputStream fout = new FileOutputStream("C:\\Users\\Sivaranjani Gopal\\eclipse-workspace2\\JavaProgramming\\src\\xmlparse\\stud.xml");
		TransformerFactory tfactory = TransformerFactory.newInstance();
		Transformer t = tfactory.newTransformer();
		t.transform(new DOMSource(doc), new StreamResult(fout));
		
		System.out.println("XML file created!");
	}
}
