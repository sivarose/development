package interfacepg;

public class Empdoc extends Empdata{

	int empn, adhr1;

	Empdoc(int emp, int empad, int empan, int adhar) {
		super(emp, empad);
		this.empn=empan;
		this.adhr1=adhar;		
	}

	@Override
	public void empaadhar() {
	}

	@Override
	public void emppanno() {
		// TODO Auto-generated method stub	
	}
	public static void main(String[] args) {
		
		Empdoc edoc = new Empdoc(123, 3333,234242,423342);
		System.out.println(edoc.hashCode());
		edoc.empname();
		
	}
	

}
