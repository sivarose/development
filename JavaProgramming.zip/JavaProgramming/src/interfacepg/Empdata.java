package interfacepg;

public abstract class Empdata implements Employee{

	int empid,empaddr;  
	Empdata(int emp,int empad)
	{
		this.empid=emp;
		this.empaddr=empad;	
	}
	@Override
	public void empname() {

		System.out.println("employee details - abstract parent class");
		System.out.println(this.hashCode());
		System.out.println(s);
	}

	@Override
	public void empid() {
		
		System.out.println("Id");

	}

	@Override
	public void empaddr() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void empbankdetails() {
		// TODO Auto-generated method stub
		
	}
	
	
}
