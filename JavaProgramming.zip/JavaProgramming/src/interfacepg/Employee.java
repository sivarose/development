package interfacepg;

public interface Employee {
	
	int s=98;
	
	public abstract void empname();
		
	public abstract void empid();
	
	public abstract void empaddr();
	
	public abstract void empbankdetails();
	
	public abstract void empaadhar();
	
	public void emppanno();
	
}
