package collectionprg;

import java.util.LinkedHashSet;

public class LinkedHashSetPrg {

	public static void main(String[] args) {
	
		
		LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
		
		lhs.add(23);
		lhs.add(34);
		
		System.out.println(lhs);
		
	}
	
   
	
	
}
