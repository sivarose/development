package collectionprg;

import java.util.HashSet;
import java.util.Iterator;

public class ElementExistHashSet {

	public static void main(String[] args) {
		HashSet<Integer> hs1 = new HashSet<Integer>();
		hs1.add(444);
		
		HashSet<Integer> hs= new HashSet<Integer>();
		
		hs.add(12);
		hs.add(234);
		hs.add(123);
		hs.add(12);
		hs.addAll(hs1);
		System.out.println(hs);
		hs.removeAll(hs1); 

		System.out.println(hs);		
		Iterator<Integer> it = hs.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
	System.out.println("afterremoval");	
		
	hs.remove(234);
	
	Iterator<Integer> it1=hs.iterator();
	
	while(it1.hasNext())
	{
		System.out.println(it1.next());
	}	
	
	System.out.println(hs);
	
	boolean isExists =hs.contains(129);
	
	System.out.println(isExists);
	
	}
	
   
	
	
}
