package collectionprg;

import java.util.HashSet;
import java.util.Iterator;

public class SizeOfHashSet {

	public static void main(String[] args) {
		
		
		HashSet<Integer> hs= new HashSet<Integer>();
		
		hs.add(12);
		hs.add(234);
		
		System.out.println(hs.size());
		
		Iterator<Integer> it = hs.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		System.out.println(hs);
		
		
		
	}
	
	
	
	
	
}
