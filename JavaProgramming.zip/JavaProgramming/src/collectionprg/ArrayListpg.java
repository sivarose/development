package collectionprg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class ArrayListpg {

public static void main(String[] args) {
		
		ArrayList arr1 = new ArrayList();	
		arr1.add(10);   
		arr1.add("A");
		arr1.add("null");
		arr1.add(1,"D");
		System.out.println(arr1);
		
		TreeSet tr1 = new TreeSet();	
			tr1.add(1);	
			System.out.println(tr1);	
	/*
		Iterator<Integer> itr = arr1.iterator();		
		
		while(itr.hasNext())
		{
			int a=itr.next();
			System.out.println(a);
		}*/
}
}