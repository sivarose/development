package collectionprg;

import java.util.HashSet;
import java.util.Iterator;

public class CopyAllElementsToObjectArray {

	
	
	public static void main(String[] args) {
			
		
	HashSet<Integer> hs= new HashSet<Integer>();
		
		hs.add(12);
		hs.add(234);
		
	Object[] obj = hs.toArray();
	
	for(int i=0;i<obj.length;i++)
	{
		System.out.println(obj[i]);
		
	}
	
	System.out.println(obj);
	System.out.println("hash set elements");
		
		Iterator<Integer> it = hs.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}

		
		hs.removeAll(hs);
		
		System.out.println(hs);
	}

	
	}

