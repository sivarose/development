package collectionprg;

import java.util.HashSet;
import java.util.Iterator;

public class RemoveElementHashSet {

	public static void main(String[] args) {
		
		
		HashSet<Integer> hs= new HashSet<Integer>();
		
		hs.add(12);
		hs.add(234);
		hs.add(123);
		hs.add(12);
		
		
		Iterator<Integer> it = hs.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
	System.out.println("afterremoval");	
		
	hs.remove(234);
	
	Iterator<Integer> it1=hs.iterator();
	
	while(it1.hasNext())
	{
		System.out.println(it1.next());
	}	
	
	System.out.println(hs);
	
	boolean isRemoved =hs.remove(12);
	
	System.out.println(isRemoved);
	
	}
	
   
	
	
}
