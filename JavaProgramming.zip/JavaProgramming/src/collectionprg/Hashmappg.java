package collectionprg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

class Employee{
	
	int empid;
	String empname;
	int empsal;
	
}



public class Hashmappg {

	public static void main(String[] args) {
		
		
		HashMap<String,String> hm = new HashMap<String,String>();
				
		hm.put("name", "siva");
		hm.put("id", "10001");
		
	Iterator<Entry<String, String>> itr = hm.entrySet().iterator();
	
	while(itr.hasNext())
	{
	
	System.out.println(itr.next());
		
		
		
	}
	}
}
