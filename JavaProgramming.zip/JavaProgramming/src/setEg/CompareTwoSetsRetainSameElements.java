package setEg;

import java.util.HashSet;

public class CompareTwoSetsRetainSameElements {

	public static void main(String[] args) {	
		HashSet s1 = new HashSet();
	    s1.add(9);
	    s1.add(4);
	    s1.add(131);
	    HashSet s2 = new HashSet();
	    s2.add(19);
	    s2.add(24);
	    s2.add(131);
		s1.retainAll(s2);
		System.out.println(s1);
	}
}