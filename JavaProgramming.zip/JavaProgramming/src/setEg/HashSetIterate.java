package setEg;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetIterate {

	public static void main(String[] args) {
		
		HashSet s = new HashSet();
	    s.add(9);
	    s.add(4);
	    s.add(131);
	    System.out.println(s);
	    System.out.println(s);

	    for(Object a : s)
	    {
	    	System.out.println(a);
	    }
	    
	   Iterator i = s.iterator();
	   while(i.hasNext())
	   {
		   System.out.println(i.next()); 
		    
	   }
	   HashSet s2 = new HashSet();   
	   s2.addAll(s);
	   System.out.println(s2);
	   
	   Integer[] h = new Integer[s2.size()];
	   
	  s2.toArray(h);

	  for(Integer j :h)
	  {
		  System.out.println(j);
	  }
	}	
}

