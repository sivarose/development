package polymorphism;

class Movie {

    public void plot() {
        System.out.println("No plot here");
    }

 }

class Jaws extends Movie {
  
    public void plot() {
        System.out.println("A shark eats lots of people");
    }
}

class IndependenceDay extends Movie {
    public void plot() {
        System.out.println("Aliens attempt to take over planet earth");
    }
}

class MazeRunner extends Movie {

    public void plot() {
        System.out.println("Kids try and escape a maze");
    }
}

class StarWars extends Movie {
 
    public void plot() {
        System.out.println("Imperial Forces try to take over the universe");
    }
}

class Forgetable extends Movie {
  
    // No plot method
}


public class Main {

    public static void main(String[] args) {
	
    
    Movie m1 = new Movie();
    MazeRunner mr = new MazeRunner();
    Forgetable mr1 = new Forgetable();
    m1.plot();
    mr.plot();
    mr1.plot();
    
    }
    }   

