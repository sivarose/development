package ArrayListExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SynchronizedArrayListEg {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);	
		
		for(int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		for(Integer i : al)
		{
			System.out.println(i);
		}	
		Collections.synchronizedList(al);
				
		synchronized(al)
		{
		Iterator<Integer> itr = al.iterator();
			
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
			
			
		}
	}
}
