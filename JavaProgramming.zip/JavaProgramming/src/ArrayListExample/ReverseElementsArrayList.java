package ArrayListExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;

public class ReverseElementsArrayList {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		Collections.reverse(al);
	    System.out.println(al);  
	    
	    
	}	
}