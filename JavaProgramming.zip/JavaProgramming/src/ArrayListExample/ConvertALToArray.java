package ArrayListExample;

import java.util.ArrayList;

public class ConvertALToArray {
	
public static void main(String[] args) {
	
	ArrayList al = new ArrayList();
	
	al.add(1);
	al.add(2);
	al.add(3);
	al.add(4);
	al.add(5);
	System.out.println(al);
	Object[] ar = al.toArray();
	for(Object obj : ar)
	{
		System.out.print(obj);
	}
}   
}
