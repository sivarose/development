package ArrayListExample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ConvertingArraysToList {

	public static void main(String[] args) {
		
		String[] str = new String[] {"Siva","Ranjani","Gopal"};
		System.out.println(Arrays.toString(str));
		List l1 = Arrays.asList(str);
		System.out.println(l1);
		
		List l2 = Collections.unmodifiableList(l1);
		
	//	l2.add("Siva");
		//l2.remove("Siva");
		System.out.println(l2.get(0));

		}
}
 