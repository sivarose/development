package ArrayListExample;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListEg {

	public static void main(String[] args) {
		
	//sort	- ascending
		ArrayList al = new ArrayList();
		
		al.add("D");
		al.add("C");

		al.add("b");
		al.add("e");
				
		Collections.sort(al);
		
		System.out.println(al) ;   
	//sort - descending
		
		Collections.sort(al,Collections.reverseOrder());		
		System.out.println(al);
		
	}
	
	
	
	
}
