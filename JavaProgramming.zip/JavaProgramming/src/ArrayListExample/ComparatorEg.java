package ArrayListExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


class SortByAlphabetDescending implements Comparator<Object> {

	@Override
	public int compare(Object o1, Object o2) {		
	String s1 = o1.toString();
	String s2 = o2.toString();
	return s2.compareTo(s1);  	  
	}
}
class SortByAlphabetAscending implements Comparator<Object> {

	@Override
	public int compare(Object o1, Object o2) {
		
	String s1 = o1.toString();
	String s2 = o2.toString();
	return s1.compareTo(s2);  	
	}
}
public class ComparatorEg {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
        al.add("88");
        al.add("11");
        al.add("99");
        al.add("56");
        System.out.println(al);
        Collections.sort(al, new SortByAlphabetDescending());
        System.out.println(al);
        Collections.sort(al, new SortByAlphabetAscending());
        System.out.println(al);
}		
}
  