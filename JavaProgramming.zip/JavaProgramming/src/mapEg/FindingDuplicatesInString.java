package mapEg;

import java.util.HashMap;
import java.util.Set;

public class FindingDuplicatesInString {
	
	public static void main(String[] args) {
		
	String s = "Siva is a Java Developer";	
	String s1 = s.replaceAll("\\s", "");			
		char[] ch = s1.toCharArray();
	
		HashMap<Character,Integer> hm = new HashMap<Character,Integer>();
       
		Set<Character> s2 = hm.keySet();
		   
	  for(char c1 : ch) {
		  
		if(hm.containsKey(c1))	
	    {
	    	hm.put(c1, hm.get(c1)+1);
	    }
	    else
	    	hm.put(c1, 1);    	
	    }    
	    
for(Character cha : s2)
{
	  if(hm.get(cha)>1)
		  
	  {
		  System.out.println(cha+" occurs "+hm.get(cha)+" times");
	  }
	  
  }
	}

}
