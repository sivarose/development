package mapEg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class InsertAndRetrieveElements {

	public static void main(String[] args) {
		
	HashMap<Integer,String> m = new HashMap<Integer,String> ();
		
		m.put(19, "Siva");  
		m.put(2, "Ranjani");
		m.put(11, "JavaDeveloper");
		m.put(24, "Gopal");			
		System.out.println(m);
		Set s = m.keySet();		
		Set s1 = m.entrySet();		

        Iterator itr = s1.iterator();	

        while(itr.hasNext())
        {
        	Map.Entry m1 = (Map.Entry) itr.next();   
        	System.out.println(m1.getKey()+"....."+m1.getValue());
        	
        }
        
	}
	
	
	
	
}
