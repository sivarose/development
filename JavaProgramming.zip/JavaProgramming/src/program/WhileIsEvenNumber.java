package program;

public class WhileIsEvenNumber {

	public static void main(String[] args) {
	//	System.out.println(isEvenNumber(19));
		
		isEvenNumberCalculate(4,20);
	}
	
	public static boolean isEvenNumber(int number)
	{
		while(true)
		{
			if(number%2==0)
				return true;
				break;
		}
		return false;
		
	}
	
	public static void isEvenNumberCalculate(int number1, int number2)
	{	
		int count=0;
		while(number1<=number2)
		{

			number1++;
		if(!isEvenNumber(number1))
		{
			
			continue;
		}
		System.out.println(number1+" is an even number");

		count++;
		if(count==5)
		break;
		}
		
		System.out.println(count+" is the total number of even numbers");
	}
	
}
