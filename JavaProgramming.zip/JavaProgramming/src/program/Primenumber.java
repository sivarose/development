package program;

public class Primenumber {

	public static void main(String[] args) {
			
		numberOfprimenumbers(1,10);
	}
	
	public static boolean isPrimeNumber(int number)
	
	{
		if(number==1)
			return false;
					
			for(int i=2;i<=number/2;i++)
			{
				if(number%i==0)
					
					return false;
			}
			System.out.println(number+" is a prime number");
				return true;		
	}
		
	public static void numberOfprimenumbers(int r1, int r2)
	{
		int count =0;
		for(int i=r1;i<=r2/2;i++)
		{
		     	
			if(isPrimeNumber(i))
				count++;
			if(count==3)
		{System.out.println("3 prime numbers");
				break;}
		}
		
	}
}
