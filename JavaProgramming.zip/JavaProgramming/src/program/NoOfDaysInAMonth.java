package program;

public class NoOfDaysInAMonth {

	
	public static void main(String[] args) {
		
		getDaysInMonth(1,-2020);
		
	//System.out.println(isLeapYear(2020));
	}
	
	
	
	public static boolean isLeapYear(int year)
	{
		
		if(year<1 || year>9999)
			return false;
		else if(year>=1 && year<=9999)
		{
			if((year%4==0 && year%100!=0) || (year%400==0 && year%100==0))
				return true;
			else return false;
						
		}
		else return false;
		
	}
	
	public static void getDaysInMonth(int month, int year)
	{
		if(month<1 || month>12 || year<1 || year>9999)
			System.out.println("Invalid value");
		else if(month==1 || month==3  || month==5  ||  month==7  ||  month==8  ||  month==10  || month==12)
			System.out.println(month+" has 31 days ");
		else if(month == 4 || month == 6 || month == 9 || month == 11)
			System.out.println(month+" has 30 days");
		else if(month == 2)
		{
			
			if(isLeapYear(year))
			{
				System.out.println(month+" has 29 days and it is a leap year");
			}
			else
				System.out.println(month+" has 28 days and not a leap year");
		}else
				System.out.println("Enter valid");
			
		
	}
	
	
}
