package program;

public class Digitsumchallenge {

	
	public static void main(String[] args) {
		System.out.println(sumDigits(32123));
	}

	
	public static int sumDigits(int number)
	{
		int sum=0,n;
		if(number<=10 || number<0)
			return -1;
		else{
			
			while(number!=0)
			{n=number%10;
			sum=sum+n;
			number=number/10;
			}
			return sum;
		}
	}
	
	
}
