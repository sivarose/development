package program;

public class Speedconverter {
	
	public static void main(String[] args)
	{

    printConversion(75.114);

	}	
	public static long tomilesPerHour(double kilometerperhour)
	{
	 
        long rounded = Math.round(kilometerperhour);
		return rounded;		
	}
	
	public static void printConversion(double kilometerperhour)
	
	{
		if(kilometerperhour<0)
		{
			System.out.println("Invalid value");
		}		
		else
		{
			double milesperhour= kilometerperhour/1.609;
		long round = tomilesPerHour(milesperhour);			
		
		System.out.println(kilometerperhour+" km/h = "+round+" mi/h");
		}
		}
}
