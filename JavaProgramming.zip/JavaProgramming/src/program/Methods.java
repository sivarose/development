package program;

public class Methods {

public static void main(String[] args)
{
	int highScore = calculateFinalScore(true, 100, 500);	
	System.out.println(highScore);
	highScore = calculateFinalScore(false, 200, 600);
	System.out.println(highScore);
	
}	

public static int calculateFinalScore(boolean gameover, int score, int bonus)
{
	if(gameover)
	{
		int finalscore = score*bonus;
		finalscore+=100;
		return finalscore;
	}
	else 
	{
		return -1;
	}
	}

}
