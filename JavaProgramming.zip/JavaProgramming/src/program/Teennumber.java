package program;

public class Teennumber {

	public static void main(String[] arg)
	{
		
		boolean t1 = hasTeen(22,23,34);
		System.out.println(t1);
		boolean t2 = isTeen(13);
		System.out.println(t2);
	}
	
	public static boolean hasTeen(int a1, int a2, int a3)
	{
		if((a1>=13 && a1<=19) || (a2>=13 && a2<=19) || (a3>=13 && a3<=19) )
		{
			return true;
		}
		else return false;
	}
	
	
	public static boolean isTeen(int a1)
	{
		if(a1>=13 && a1<=19)
		{
			return true;
		}
		else return false;
	}
	
	
}
