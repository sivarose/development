package program;

public class Equalsum {

	public static void main(String[] abd)
	{
		boolean e1=hasEqualSum(1,-1,0);
		System.out.println(e1);
	}
	
	public static boolean hasEqualSum(int a,int b,int c)
	{
		
		int d=a+b;
		if(d==c)
			return true;
		else return false;
		
	}
	
	
	
}
