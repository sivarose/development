package program;

public class Vipcustomer {

	private String name;
	private int creditlimit;
	private String emailaddress;
	
	
	public String getEmailaddress() {
		return emailaddress;
	}
	

	
	public Vipcustomer()
	{
		this("default name",500,"default@gmail.com");
	}
	

	 public Vipcustomer(String name, int creditlimit)
	{
		 
		 this(name,creditlimit,"unknown@yahoo.com");
	}
	
	public Vipcustomer(String name, int creditlimit, String emailaddress)
	{
		
		this.setName(name);
		this.setCreditlimit(creditlimit);
		this.emailaddress=emailaddress;
	}



	public int getCreditlimit() {
		return creditlimit;
	}



	public void setCreditlimit(int creditlimit) {
		this.creditlimit = creditlimit;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
	
	
	
}
