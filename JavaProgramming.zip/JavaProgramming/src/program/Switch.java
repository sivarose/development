package program;

public class Switch {

	
	public static void main(String[] args) {
	
		
		char alphabet='D';
		switch(alphabet){
		
		case 'A':
			System.out.println("A is found");
			
		break;
		case 'B':
			System.out.println("B is found");
			
		break;
		case 'C': case 'D': case 'E':
			System.out.println(alphabet+" is found");
			
		break;
				
		
		
		default:
			System.out.println(alphabet+" is not found");
			break;
			
		
		}
		
		
		String month="FebruarY";
		
		switch(month.toLowerCase())
		{
		case "january":
			System.out.println("Jan is found");
			
		break;
		case "february": case "march": case "april":
			System.out.println(month+" is found");
			
		break;
				
		default:
			System.out.println(month+" is not found");
			break;
		}
		
		
	}
		
}
