package program;

public class Wallarea {

	
	private double width;
	private double height;
	
	
	public Wallarea()
	{	this(9.0,5.0);
	}
	public Wallarea(double width, double height)
	{
		
		if(width<0)
			this.width=0;
		else
			this.width=width;
		
		if(height<0)		
		this.height=0;
		else
		this.height=height;
		
	}

	public double getWidth() {
		if(this.width<0)
		return 0;
		else
			return this.width;
	}
	public double getHeight() {
		if(this.height<0)
			return 0;
			else
				return this.height;
		}
	public double getArea()
	{
		double area = getWidth()*getHeight();
		return area;
	}
	public void setHeight(double d) {
	
		if(height<0)
			this.height=0;
		else
			this.height=d;
	
	}
	}
	
	
