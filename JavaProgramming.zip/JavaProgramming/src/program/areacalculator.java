package program;

public class areacalculator {

	public static void main(String[] arg)
	
	{
		System.out.println(area(-1));
	}
	
	public static double area(double radius)
	{
		
		if(radius<=-1.0)
		{
			return -1.0;
		}
		else
		{
			double a= radius*radius*Math.PI;
			return a;
		}
	}
	
	public static double area(double x, double y)
	{
		
		if(x<=-1.0 || y<=-1.0)
		{
			return -1.0;
		}
		else
		{
			double a1 = x*y;
			return  a1;
		}
	}
}
