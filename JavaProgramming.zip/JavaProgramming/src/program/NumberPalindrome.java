package program;

public class NumberPalindrome {

	
	public static void main(String[] args) {
		System.out.println(isPalindrome(707));
	}
	
	public static boolean isPalindrome(int number)
	{
		int sum=0,n;
		int n1=number;
		while(n1!=0)
		{
			n=n1%10;
			sum=(sum*10)+n;
			n1=n1/10;			
		}
		if(sum==number)
		{
			return true;
		}
		else
			return false;
		 
			
		
	}
	
	
}
