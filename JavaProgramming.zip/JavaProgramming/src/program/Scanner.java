package program;

public class Scanner {

	public static void main(String[] args) {
		
		
		
		
		
		
	}
	
}
