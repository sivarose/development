package program;

public class SumCalculatorClassGetterSetter {

	public double firstNumber;
	private double secondNumber;
	
	
	public  SumCalculatorClassGetterSetter()
	{
		this(1.4,2.3);
		System.out.println("Empty constructor called");
		
	}
	
	public  SumCalculatorClassGetterSetter(double firstnumber, double secondnumber)
	{
		System.out.println("main constructor");
		
		this.firstNumber= firstnumber;
		this.secondNumber=secondnumber;
		
		
	}
	
	
	
	public double getfirstNumber()
	{
		return firstNumber;
		
	}
	
	public double getsecondNumber()
	{
		return secondNumber;
		
	}
	
	public double stFirstNumber(double firstNumber)
	{
		
		this.firstNumber= firstNumber;
		return firstNumber;
	}
	
	public double stSecondNumber(double secondNumber)
	{
		this.secondNumber=secondNumber;
		if(secondNumber>6)
			return secondNumber;
			else return -1;
			
	}
	
	public double getAdditionResult()
	{
		double sum=0;
		
		sum=firstNumber+secondNumber;
		return sum;
	}
	
	public double getSubtractionResult()
	{
		double dif=0;
		
		dif=firstNumber-secondNumber;
		return dif;
	}
	
	public double getMultiplicationResult()
	{
		double mul=0;
		
		mul=firstNumber*secondNumber;
		return mul;
	}
	
	
	
}
