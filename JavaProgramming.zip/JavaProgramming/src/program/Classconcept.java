package program;

public class Classconcept {

	
	public static void main(String[] args) {
		
		/*
		 * SumCalculatorClassGetterSetter sumCalculatorClassGetterSetter = new
		 * SumCalculatorClassGetterSetter();
		 * 
		 * //System.out.println(sumCalculatorClassGetterSetter.stSecondNumber(5));
		 * 
		 * sumCalculatorClassGetterSetter.firstNumber=15;
		 * System.out.println(sumCalculatorClassGetterSetter.firstNumber);
		 * 
		 * sumCalculatorClassGetterSetter.stFirstNumber(5.0);
		 * sumCalculatorClassGetterSetter.stSecondNumber(4); System.out.println("add= "
		 * + sumCalculatorClassGetterSetter.getAdditionResult());
		 * System.out.println("subtract= " +
		 * sumCalculatorClassGetterSetter.getSubtractionResult());
		 * sumCalculatorClassGetterSetter.stFirstNumber(5.0);
		 * sumCalculatorClassGetterSetter.stSecondNumber(0);
		 * System.out.println("multiply= " +
		 * sumCalculatorClassGetterSetter.getMultiplicationResult());
		 */
		
		
		Vipcustomer vipcustomer= new Vipcustomer();
		System.out.println(vipcustomer.getName());		
		System.out.println(vipcustomer.getCreditlimit());
		System.out.println(vipcustomer.getEmailaddress());
		
		
		

Wallarea wall = new Wallarea();
System.out.println("area= " + wall.getArea()); 
wall.setHeight(-1.5);
System.out.println("width= " + wall.getWidth());
System.out.println("height= " + wall.getHeight());
System.out.println("area= " + wall.getArea());


		
		
		Vipcustomer vipcustomer1= new Vipcustomer("Siva",800);
		System.out.println(vipcustomer1.getName());
		System.out.println(vipcustomer1.getCreditlimit());
		System.out.println(vipcustomer1.getEmailaddress());

		
		Vipcustomer vipcustomer2= new Vipcustomer("Ranjani",200,"ran@1820@gmail.com");
		System.out.println(vipcustomer2.getName());
		System.out.println(vipcustomer2.getCreditlimit());
		System.out.println(vipcustomer2.getEmailaddress());
			
	}
	

}
