package composition;

public class Chair {
	
	
	private int no;
	private String color;
	
	public Chair(int no, String color)
	
	{	
		this.no=no;
		this.color=color;
	}
	
	public int getNo() {
		return no;
	}
	
	public String getColor() {
		return color;
	}
	
	
	

}
