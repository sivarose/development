package composition;

public class House {
	
	
	private Bed bed;
	private Cupboard cupboard;
	private Chair chair;

	public House(Bed bed, Cupboard cupboard, Chair chair)
	{		
		this.bed=bed;
		this.cupboard=cupboard;
		this.chair=chair;
		
	}
	
	public Bed getBed() {
		return bed;
	}
	public Cupboard getCupboard() {
		return cupboard;
	}
	public Chair getChair() {
		return chair;
	}
	
	
	

}
