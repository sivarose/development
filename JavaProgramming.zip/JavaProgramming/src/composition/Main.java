package composition;

public class Main {

    public static void main(String[] args) {
		/*
		 * Dimensions dimensions = new Dimensions(20, 20, 5); Case theCase = new
		 * Case("2208", "Dell", "240", dimensions);
		 * 
		 * Monitor theMonitor = new Monitor("27inch Beast", "Acer", 27, new
		 * Resolution(2540, 1440));
		 * 
		 * Motherboard theMotherboard = new Motherboard("BJ-200", "Asus", 4, 6,
		 * "v2.44"); PC thePC = new PC(theCase, theMonitor, theMotherboard, dimensions);
		 * thePC.getMonitor().drawPixelAt(1500, 1200, "red" );
		 * thePC.getMotherboard().loadProgram("Windows 1.0");
		 * thePC.getTheCase().pressPowerButton(); thePC.getDimensions().area();
		 */ 
    	
    
    	Bed bed = new Bed("sleepwell",2, new Bedsheet(5,6));
    	
    	Cupboard cup = new Cupboard(3,"Brown");
    	
    	Chair chr = new Chair(2,"Ash");
    	
    	House h = new House(bed, cup, chr);
    	
        h.getBed().bedUp();
        
    
    
    }
    
    
    
    
    
    
}
