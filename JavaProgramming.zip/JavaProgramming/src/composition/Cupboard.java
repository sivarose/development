package composition;

public class Cupboard {
	private int number;
	private String clr;
	
	public Cupboard(int no, String color)
	
	{	
		this.number=no;
		this.clr=color;
	}
	
	public int getNo() {
		return number;
	}
	
	public String getColor() {
		return clr;
	}

}
