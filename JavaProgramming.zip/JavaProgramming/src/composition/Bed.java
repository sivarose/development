package composition;

public class Bed {

	private String matress;
	private int pillows;
	private Bedsheet bedsheet;
	
	
	
	public Bed(String matress, int pillows, Bedsheet bedsheet)
	{
		
		this.matress=matress;
		this.pillows=pillows;
		this.bedsheet=bedsheet;
		
	}
	
	public void bedUp()
	{

		bedsheet.area();
	}
	
	
	public int getPillows() {
		System.out.println(pillows);
		return pillows;
	}



	public String getMatress() {
		return matress;
	}



	public Bedsheet getBedsheet() {
		return bedsheet;
	}
	
	
	
}

