package objectClass;

final public class ImmutableClass {
	
	private int i;
	
	ImmutableClass(int i)
	{
		this.i = i;
	   	
	}
	public ImmutableClass modify(int i)
	{
		
		if(this.i==i)
			
		{
		return this;
		}
		else
		{
			return (new ImmutableClass(i));
		}
				
	}
    public static void main(String[] args) {
		 
		ImmutableClass ic = new ImmutableClass(10);
		ImmutableClass ic2 = ic.modify(100);
		ImmutableClass ic3 = ic.modify(10);
		System.out.println(ic==ic3); 
			
	}
}
