package objectClass;

public class EqualsPg {
	
	int rollno;
	String studentname;
	
	EqualsPg(int rno, String sname)
	{
		this.rollno=rno;
		this.studentname=sname;
	}	
	public boolean equals(Object obj)
	{
	   EqualsPg s = (EqualsPg) obj;
	   if(obj instanceof EqualsPg)
	   { 
	   if(studentname.equals(s.studentname)&&rollno==s.rollno)
	   return true;
	   else
	   return false;
		   	
	}
	   return false;
	}
	
 public static void main(String[] args) {
		
		EqualsPg s1 =  new EqualsPg(001,"Siva");

		EqualsPg s2 = new EqualsPg(002,"Ranjani");
		
		EqualsPg s3 = new EqualsPg(001,"Siva");
		
		System.out.println(s1.equals(s3));

		
	} 
}
