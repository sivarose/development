package objectClass;

public class DefaultToStrings {
	
   static String sb;
   

public DefaultToStrings(String s1)
   {
	
	this.sb=s1;
   }
	
	public String toString()
	{
		return sb;
		
	}
	public static void main(String[] args) {
		
	
	DefaultToStrings df = new DefaultToStrings("Siva");
	
	System.out.println(df.toString()); 
	System.out.println(sb); 

				
	}
}
  