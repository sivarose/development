package objectClass;

import java.lang.reflect.Method;

public class GetClasspg {
	
public static void main(String[] args) throws ClassNotFoundException {
		
      Object o = new StringBuffer("Siva");
      Class c = o.getClass();
      
   //   Class c = Class.forName("java.lang.Object");
      
      System.out.println("name of the classes are:"+c.getName());
      Method[] m =  c.getDeclaredMethods();
      int count=0;
      
      for(Method m1 : m)
      {
    	  count++;
    	  System.out.println(m1.getName());
      }
		System.out.println("Total no of methods are "+count);
	}

}
    