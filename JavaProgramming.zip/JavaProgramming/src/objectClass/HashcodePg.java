package objectClass;

public class HashcodePg {
	int i;
	
	HashcodePg(int hc){
		this.i=hc;
		i=10;
	}
	
	public int hashCode()
	{
		return i;
		
	}
	
	public static void main(String[] args) {
		    
		HashcodePg s = new HashcodePg(34687);
		System.out.println(s.toString());

	}

}
