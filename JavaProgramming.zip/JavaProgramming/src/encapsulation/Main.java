package encapsulation;

public class Main {

	
	
	public static void main(String[] args) {
		
		
		Printer p = new Printer(102,15,true);
		
		p.duplexPrinter();
		p.simulatePrinting();;
		p.tonerFillUp();
		
		
		
		
	}
}
