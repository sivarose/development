package encapsulation;

public class Printer {
	
	private int tonerlevel;
	private int noOfpagePrinted;
	private boolean duplexPrinter;
	
	
	public Printer(int tonlvl, int noPgprn, boolean dupl)
	{
		if(tonlvl>=0 && tonlvl<=100)
		{
		this.tonerlevel=tonlvl;
		}
		else 
			this.tonerlevel=-1;
		this.noOfpagePrinted=noPgprn;
		this.duplexPrinter=dupl;
	}

	 public void tonerFillUp()
	 {
		 
		 if(tonerlevel>=0 && tonerlevel<100)
		 {
			System.out.println("Toner filled upto "+tonerlevel); 
		 }
		 
		 else
			 System.out.println("Toner is full");
	 }
	
	 public void simulatePrinting()
	 {
		 System.out.println(noOfpagePrinted);
	 }
	public void duplexPrinter()
	{
		
		if(isDuplexPrinter())
			System.out.println("It is a duplex printer");
		else
			System.out.println("It is not a duplex printer");			
			
	}

	public int getTonerlevel() {
		return tonerlevel;
	}


	public int getNoOfpagePrinted() {
		return noOfpagePrinted;
	}


	public boolean isDuplexPrinter() {
		return duplexPrinter;
	}
	
	
	
	

}
