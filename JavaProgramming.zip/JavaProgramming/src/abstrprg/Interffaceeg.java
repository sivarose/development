package abstrprg;

public class Interffaceeg implements Colt1 {

	@Override
	public void read() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void write() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void access() {
		// TODO Auto-generated method stub
		
	}

	

	
	
}
