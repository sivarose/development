package abstrprg;

public interface Colt1 {

	public void read();
	public void write();
	public void access();
	
}
