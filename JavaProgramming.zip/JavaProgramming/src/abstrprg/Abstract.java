package abstrprg;

import java.util.Scanner;

 abstract class account{
	
 int accountno;
 String name;
 int amount;
 
	abstract void deposit();
	abstract void withdraw();
}

class sbaccount extends account{
	
	int interest=4;
	final int minbal=10000;
	int bal=45000;
		void deposit()
   {
		System.out.println("sb class deposit");
	
			bal=minbal+amount+interest;
			System.out.println("Amount balance in account"+bal);
		}
	
	void withdraw()
	{
		
		
		System.out.println("sb class withdraw");
	
		if(amount>minbal)
		{
			System.out.println("Amount is not avl for withdraw since min bal to be maintained");
		}
		else
		{
			bal=amount-bal;
			System.out.println("Amount available after withdraw"+bal);
			
		}
		
	}

	
}

class curaccount extends account {
	
	final int minbal=20000;
	int bal = 50000;
	void deposit()
	{
		System.out.println("cur class deposit");

		bal=minbal+amount;
		System.out.println("Amount balance in account"+bal);

	
	}
	void withdraw()
	{
		System.out.println("cur class withdraw");
		if(amount>minbal)
		{
			System.out.println("Amount is not avl for withdraw since min bal to be maintained");
		}
		else
		{
			bal=amount-bal;
			System.out.println("Amount available after withdraw"+bal);
			
		}
		
		
	}

}



public class Abstract {


	public static void main(String[] args) {
		
		account sb;
		sb = new sbaccount();	
		account sb1;
		sb1=new curaccount();
		System.out.println("Choose the type of bank account to be opened");
	Scanner sc = new Scanner(System.in);
		
		String actype=sc.next();
		
		if(actype.equalsIgnoreCase("sb"))
		{
			sb.accountno=1234;
			sb.amount=50000;
			sb.name="siva";
			System.out.println("account no "+sb.accountno);
			System.out.println("amount "+sb.amount);
			System.out.println("name "+sb.name);
			sb.withdraw();
			
			
		} 
	
		else if(actype.equalsIgnoreCase("cr"))
		{
			sb1.accountno=3232;
			sb1.amount=15000;
			sb1.name="ranjani";
			System.out.println("account no "+sb1.accountno);
			System.out.println("amount "+sb1.amount);
			System.out.println("name "+sb1.name);
			sb1.deposit();
			
			
		} 
		else
			System.out.println("Choose a valid account");
	
		sc.close(); 
		
	
		
	}
	}
	
	
