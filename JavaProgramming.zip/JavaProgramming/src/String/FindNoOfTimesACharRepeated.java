package String;

public class FindNoOfTimesACharRepeated {	
		
	public static void main(String[] args) {
	
	String s = "sivaranjani";
	int count=0;
	
	char[] ch = s.toCharArray();
	
	for(int i=0;i<ch.length;i++)
	{
		count=0;
		for(int j=0;j<ch.length;j++)
		{
		if(ch[i]==ch[j])
		{
		    count++; 
		}
	}
		System.out.println(ch[i]+" occurred"+count+" times");
	}
	}
}
	
