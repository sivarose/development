package String;

import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicatesInString {

	public static void main(String[] args) {
		
		
		String s="askads";
		char[] ch= s.toCharArray();
		
			
	}
	
	
	
	
}
