package String;

public class RemoveSpecialCharacters {

	
	public static void main(String[] args) {
		String s = "@#$ %^&a bcn";
		s=s.replaceAll("[^A-Za-z0-9]", "");
		System.out.println(s);
	}
}
