package String;

public class Toggle {
	
	public static void main(String[] args) {
			
		String s = "This is Sivaranjani a Java developer";
		
		String[] ar = s.split("\\s");
		String g="";
		 
		for(String a1 : ar)
		{
			StringBuilder sb = new StringBuilder(a1);
			sb.reverse();
			String first=sb.substring(0,1);
			String remaining=sb.substring(1);
			g=g+first.toLowerCase()+remaining.toUpperCase()+" ";
			
		}
		
		System.out.println(g);
		
	}
	
	
	

}
