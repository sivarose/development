package String;

public class Immutable {

	int i=10;
	int j=20;
	
	public static void main(String[] args) {
			
		String s = new String("dfg");
	
		String f = new String("dfg");
	
		System.out.println(s);
		if(s.equalsIgnoreCase(f))
			System.out.println("true");
		
		System.out.println(s.hashCode());
		System.out.println(f.hashCode());
		
		Immutable im = new Immutable();
		System.out.println(im);
	
	}	
}
