package String;

public class CapitalFirstLetter {
	
	public static void main(String[] args) {
		
			
		String s = "She is my friend";
	    String words[]=s.split("\\s");
	    String capitalizeWord="";
	    
	    for(String n : words)
	    {	 
		String first=n.substring(0,1);
	//	System.out.println(first); 
		String afterfirst = n.substring(1); 
	//	System.out.println(afterfirst);
        capitalizeWord+=first.toUpperCase()+afterfirst+" "; 
      //X
	    }
	    System.out.println(capitalizeWord);
        
	    
		String last=s.substring(12);
		System.out.println(last);
		
	}
}
