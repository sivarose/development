package String;
 
public class ReverseString {
 	
	public static void main(String[] args) {
		
		String s="siva";
		String rev = "";
	
		   char[] c = s.toCharArray();
			
	   
	   for(int i=c.length-1;i>=0;i--)
	   {
		   
		   rev = rev+c[i];
	   }    
		
	   
	   System.out.println(rev);

		if(rev.equalsIgnoreCase(s))  
			
			System.out.println("It is a palindrome");
					
			 StringBuilder sb = new StringBuilder(s);
			 
			System.out.println(sb.reverse());
	      	
	}
}
  