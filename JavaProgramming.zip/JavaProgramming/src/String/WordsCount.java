package String;

public class WordsCount {

	public static void main(String[] args) {
		
		
		String s= "ThisisJava";
		
		String[] s1=s.split("\\s");
		
		int n = s1.length;		
		System.out.println(n);
			
	}
	
}
