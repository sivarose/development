package String;

public class StringImmutableProve {

	    public static void referenceCheck(String x, String y) {  
	        if (x == y) {  
	            System.out.println("Both pointing to the same reference");  
	   
	        } else {  
	            System.out.println("Both are pointing to different reference");  
	        }  
	    } 
	    
	    public static void main(String[] args) {  
	        String st1 = "Java";  
	        String st2 = "Java";  
	        System.out.println("Before Modification in st1 value is "+st1);  
	        referenceCheck(st1, st2);  
	        st1 += "Siva";  
	        System.out.println("After Modification the value is "+st1);  
	        referenceCheck(st1, st2);  
	        
	    }  
	    
}
