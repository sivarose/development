package String;

public class ReverseEachWord {
	
	
	public static void main(String[] att) {
		
		String s = "I love India";
		String[] s1=s.split(" ");
		
		
		
		String rev="";
		
		for(String s3: s1)
		{
			StringBuilder sb = new StringBuilder(s3);
		    sb.reverse();
			rev=rev+sb.toString()+" ";
			
		}
		System.out.println(rev);
			
	}

}
