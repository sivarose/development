package String;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		
		String s="Mother in law";
		String s1="Hitler Woman";
		
		String str=s.replaceAll("\\s", "");

		String str1=s1.replaceAll("\\s", "");
		
		char[] as=str.toLowerCase().toCharArray();
		char[] as1=str1.toLowerCase().toCharArray();
	
		Arrays.sort(as);		
		Arrays.sort(as1);
		
		if(Arrays.equals(as, as1))
			System.out.println("It is an anagram");
		else
			System.out.println("It is not an anagram");
		
		
	}
	
	
	
}
