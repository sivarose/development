package String;

import java.util.HashMap;
import java.util.Iterator;

public class FindNoOfDuplicatesWord {

	public static void main(String[] args) {
		
		String s1 = "Siva is a Java Developer is a Software Engineer";		
		
	   	String[] s2 = s1.split(" ");
   
		
        HashMap<String,Integer> hm = new HashMap<>();		
		
		for(String s: s2)
		{
			
			if(hm.containsKey(s))
			{
				hm.put(s,hm.get(s)+1);
			}
			else
				{hm.put(s, 1);
			
				}
			
		}
		
		Iterator<String> it = hm.keySet().iterator();
		
		while(it.hasNext())
		{
			
			String temp = it.next();
			
			if(hm.get(temp)>1)
			{
				System.out.println(temp+" word occurs "+hm.get(temp)+" times");
			}
		}
		
		
	}
		
}


