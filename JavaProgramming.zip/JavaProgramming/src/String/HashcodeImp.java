package String;

import java.util.HashMap;

public class HashcodeImp {

		public static void main(String[] args) {
			 	HashMap<String,Integer> hm = new HashMap<>();
			// 	Test t = new Test();
			 	hm.put("siv", 1);
			 	hm.get("siv");
		}
}

 class Test {
	
	public int hashCode()
	{
	 	System.out.println("Hash method is called..");
		return super.hashCode();
	}
	
	
 }
