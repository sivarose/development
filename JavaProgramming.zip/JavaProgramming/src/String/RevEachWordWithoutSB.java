package String;

public class RevEachWordWithoutSB {

	
	
	public static void main(String[] args) {
	
		String s1= "Siva is a Java Developer";
		
		String[] sa = s1.split(" ");
		String rev1 ="";

		
		for(int i=0;i<sa.length;i++)
		{
			String word=sa[i];
			String rev = "";
			
			for(int j=word.length()-1;j>=0;j--)
			{
				
				rev=rev+word.charAt(j);
			}
			
			rev1=rev1+rev+" ";
		}		
		
		System.out.println(rev1);
		
}
	
	
}
