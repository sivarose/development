package String;

import java.util.HashMap;
import java.util.Iterator;

public class FindNoOfDuplicatesInString {	
		
	public static void main(String[] args) {
				
		String s1="Sivaranjani";
		
		char[] ca = s1.toCharArray();
		
		HashMap<Character,Integer> hm = new HashMap<>();
	
		for(char c : ca)
		{
			
			if(hm.containsKey(c))
			{
				hm.put(c, hm.get(c)+1);
			}
			else
			{
				hm.put(c, 1);	
			}
		}
		System.out.println(hm);
		
		
		Iterator<Character> tr = hm.keySet().iterator();
		while(tr.hasNext())
		{
			char tempst = tr.next();
			if(hm.get(tempst)>1)
			{
				System.out.println(tempst+" is occurred "+hm.get(tempst)+" times");
			}	
		}
	}
}
