package String;

public class CountuppercaseLowecaseSpecialChar {

	
	public static void main(String[] args) {
				
		String s="#$@#sdfd ADbb 99b#";
		int uc=0;
		int lc=0;
		int dig=0;
		int spec=0;
		
		String s1=s.replaceAll("\\s", "");
		char[] ch = s1.toCharArray();
		
		for(int i=0;i<=ch.length-1;i++)
		{			
			if(ch[i]>='A' && ch[i]<='Z')
			{	uc++;
				ch[i]='U';
				System.out.print(ch[i]);
			}
			else if(ch[i]>='a' && ch[i]<='z')
				{lc++;
				ch[i]='L';
				System.out.print(ch[i]);

				}
			else if(ch[i]>='0' && ch[i]<='9')
				{dig++;
				ch[i]='N';
				System.out.print(ch[i]);

				}
			else
			{
				spec++;
				ch[i]='S';
				System.out.print(ch[i]);
						
		}				
		}
		System.out.println(uc);
		System.out.println(lc);
		System.out.println(dig);
		System.out.println(spec);
		
	}
}