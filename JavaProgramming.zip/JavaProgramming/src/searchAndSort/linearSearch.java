package searchAndSort;

import java.util.Scanner;

public class linearSearch {
	
public static int linear(int arr[], int n)
{ 
	   for(int i=0;i<arr.length;i++)
	   {
		   
		   if(arr[i]==n)
			   return i;
	   }
	   return -1;
	   
}	  
public static void main(String[] args) {
	int arr[] = {10,20,30,40,50};
	   int count=0;
	 Scanner sc = new Scanner(System.in);	
		System.out.println("Enter the no: ");
	   int n=sc.nextInt();
	   int n2 = linear(arr,n);
	   if(n2==-1)
		   System.out.println("Element not present in the array");
	   else
		   System.out.println("Element present in the array of index "+n2);
}

}