package searchAndSort;

import java.util.Arrays;
import java.util.Scanner;

public class Binarysearch {
	
public static int binary(int arr[], int n)
{ 
	 
	int l=0,r=arr.length-1;
	
	while(l<=r)
	{
       int m= l + r-l/2;
		if(arr[m]==n)
			return m;
		 if(arr[m]>n)
			r=m-1;
		 else 
			l=m+1;		
	}

	return -1;
	
}	  
public static void main(String[] args) {
	int arr[] = {75,10,20,30,40,50};
	Arrays.sort(arr);
	   int count=0;
	 Scanner sc = new Scanner(System.in);	
		System.out.println("Enter the no: ");
	   int n=sc.nextInt();
	   int n2 = binary(arr,n);
	   if(n2==-1)
		   System.out.println("Element is not present in the array");
	   else
		   System.out.println("Element present in the array of index "+n2);
}

}