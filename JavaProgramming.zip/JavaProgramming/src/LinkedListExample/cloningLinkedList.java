package LinkedListExample;

import java.util.LinkedList;

public class cloningLinkedList {
	
	public static void main(String[] args) {
		
		LinkedList l1 = new LinkedList();
			
			l1.add("Siva");
			l1.add("Ranjani");
			l1.add("Gopal");
			l1.add("JavaDeveloper");
			l1.addFirst("Savick");
			
			System.out.println(l1);
			 LinkedList l2 = (LinkedList) l1.clone();
			 
			 System.out.println(l2);
	
}
}
