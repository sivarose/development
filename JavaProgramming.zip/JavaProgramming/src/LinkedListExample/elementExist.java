package LinkedListExample;

import java.util.LinkedList;

public class elementExist {
	
public static void main(String[] args) {
	
	LinkedList l1 = new LinkedList();
	
	l1.add("Siva");
	l1.add("Ranjani");
	l1.add("Gopal");
	l1.add("JavaDeveloper");
	String s = "Gopal";
	boolean cont = l1.contains(s);
	if(cont)
	{
		int pos = l1.indexOf(s);
		System.out.println(pos);
	}
	
	else
		System.out.println("Element does not exists");
}	

}
