package LinkedListExample;

import java.util.ArrayList;
import java.util.LinkedList;

public class joinArrayListWithLinkedList {

	public static void main(String[] args) {
		
		LinkedList l1 = new LinkedList();
			
			l1.add("Siva");
			l1.add("Ranjani");
			l1.add("Gopal");
			l1.add("JavaDeveloper");
		
			ArrayList al = new ArrayList();
			
			al.add("D");
			al.add("C");

			al.add("b");
			al.add("e");
					
            l1.addAll(al);
            
            System.out.println(l1);
			
			
	}
}
