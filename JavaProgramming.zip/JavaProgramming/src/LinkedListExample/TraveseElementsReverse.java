package LinkedListExample;

import java.util.Iterator;
import java.util.LinkedList;

public class TraveseElementsReverse {

public static void main(String[] args) {
		
LinkedList l1 = new LinkedList();
	
	l1.add("Siva");
	l1.add("Ranjani");
	l1.add("Gopal");
	l1.add("JavaDeveloper");
	
	
	Iterator i = l1.descendingIterator();
	
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	
	}
		
	
}
