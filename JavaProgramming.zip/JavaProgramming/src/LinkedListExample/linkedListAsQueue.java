package LinkedListExample;

import java.util.LinkedList;

public class linkedListAsQueue {

  public static void main(String[] args) {
	
	LinkedList l1 = new LinkedList();
	
	l1.offer("Siva");
	l1.offer("Ranjani");
	l1.offer("Gopal");
	l1.offer("JavaDeveloper");
	
	
	System.out.println(l1);
	
	l1.poll();
	
	System.out.println(l1);

	l1.poll();
	System.out.println(l1);

	l1.poll();
	System.out.println(l1);

	
  }
	
}
