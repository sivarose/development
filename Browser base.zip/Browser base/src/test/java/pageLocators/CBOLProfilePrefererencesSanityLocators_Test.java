package pageLocators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.SeleniumDriver;


public class CBOLProfilePrefererencesSanityLocators_Test {

	
	@FindBy(xpath="//span[contains(text(),'Profiles')]")
	public WebElement AngprofileLink;
	
	@FindBy(xpath="//span[@class='profileIconDesktop']")
	public WebElement profileLink;
	
	
	@FindBy(xpath="//a[contains(text(),'Contact Information')]")
	public WebElement contactInformationLink;
	
	@FindBy(xpath="//a[contains(text(),'Contact Information')]")
	public WebElement AngcontactInformationLink;
	
	
	@FindBy(xpath="//span[contains(text(),'Primary Email')]//following::button")
	public WebElement emailedit;
	
	@FindBy(xpath="//input[@id='emailvalue1']")
	public WebElement emailaddress;
		
	@FindBy(xpath="//*[@class='btn btn-primary small ng-star-inserted'][text()='Save']")
	public WebElement emailsave;
	
	@FindBy(xpath="//span[@class='green bold prof_success']")
	public WebElement success;
	
	@FindBy(xpath="//input[@id='PRIMARY']")
	public WebElement mobile;
	
	@FindBy(xpath="//span[contains(text(),'Primary Mobile')]//following::button")
	public WebElement mobileedit;
	
	@FindBy(xpath="//*[@class='btn btn-primary small ng-star-inserted'][text()='Save']")
	public WebElement mobilesave;
	
	@FindBy(xpath="//span[@class='prof_success']")
	public WebElement mobilesuccess;
	
	@FindBy(xpath="//span[@class='validation-message-danger ng-star-inserted']")
	public WebElement emailinvaliderror;
	
		
	public CBOLProfilePrefererencesSanityLocators_Test()
	{
		PageFactory.initElements(SeleniumDriver.getDriver(), this);
	}


	
}
