package pageActions;

import static org.testng.Assert.assertTrue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import pageLocators.CBOLPostLoginPageLocators_test;
import pageLocators.CBOLProfilePrefererencesSanityLocators_Test;
import utils.SeleniumDriver;
import utils.SeleniumHelper;


public class CBOLProfilePreferencesSanityActions_test {
	CBOLProfilePrefererencesSanityLocators_Test cbolProfilePrefererencesSanityLocators_Test=new CBOLProfilePrefererencesSanityLocators_Test();;
	CBOL_CommonActions_test cbolCommonActions = new CBOL_CommonActions_test();
	final Log log = LogFactory.getLog(CBOLProfilePreferencesSanityActions_test.class.getName());
		
	
	public void clickOnProfileLink() {

		if(System.getProperty("profile").equalsIgnoreCase("ag")){
			log.info(">> clickOnProfileLink Angular - start");
			Actions act1 = new Actions(SeleniumDriver.getDriver());
			act1.moveToElement(cbolProfilePrefererencesSanityLocators_Test.AngprofileLink).click().build().perform();
			log.info(">> clickOnProfileLink Angular- End");
		} else {
			log.info(">> clickOnProfileLink Legacy- start");
			Actions act1 = new Actions(SeleniumDriver.getDriver());
			act1.moveToElement(cbolProfilePrefererencesSanityLocators_Test.profileLink).click().build().perform();
			log.info(">> clickOnProfileLink Legacy- End");
		}
					
	}
		
		public void clickOnContactInfo() {
			log.info(">> clickOnContactInfo - start");
			cbolProfilePrefererencesSanityLocators_Test.contactInformationLink.click();		
			WebElement element = cbolProfilePrefererencesSanityLocators_Test.contactInformationLink;
			JavascriptExecutor executor = (JavascriptExecutor)SeleniumDriver.getDriver();
			executor.executeScript("arguments[0].click();", element);
			log.info(">> clickOnContactInfo - End");			
		}		
		
		
		public void clickoneditCTA()
		{
			
			log.info(">> clickOnContactInfo - start");
			cbolProfilePrefererencesSanityLocators_Test.emailedit.click();
			log.info(">> clickOnContactInfo - End");	
			
		}
		
		public void clickonmobileeditCTA(){
			
			log.info(">> clickOnMobileEdit - start");
			cbolProfilePrefererencesSanityLocators_Test.mobileedit.click();
			log.info(">> clickOnMobileEdit - End");	
			
		}
		
		
		public void enterValueinEmailAddress(String eaddress)
		{
			
			log.info(">> enterValueinEmailAddress - start");
			Actions act = new Actions(SeleniumDriver.getDriver());
			act.moveToElement(cbolProfilePrefererencesSanityLocators_Test.emailaddress).click().sendKeys(Keys.chord(Keys.CONTROL, "a")).sendKeys(Keys.DELETE).sendKeys(eaddress).build().perform();
			log.info(">> enterValueinEmailAddress - End");
		}
		
		public void enterValueinMobilenumber(String mobile)
		{
			
			log.info(">> enterValueinMobileNumber- start");
			Actions act = new Actions(SeleniumDriver.getDriver());
			act.moveToElement(cbolProfilePrefererencesSanityLocators_Test.mobile).click().sendKeys(Keys.chord(Keys.CONTROL, "a")).sendKeys(Keys.DELETE).sendKeys(mobile).build().perform();
			log.info(">> enterValueinMobileNumber - End");
		}
		
		public void clickonEmailSave()
		{
			
			log.info(">> clickonEmailSave - start");
			cbolProfilePrefererencesSanityLocators_Test.emailsave.click();
			System.out.println("Successmaessge is displayed  " + cbolProfilePrefererencesSanityLocators_Test.success.isDisplayed());
			log.info(">> clickonEmailSave - End");
		}
		
		public void clickonMobileSave()
		{
			
			log.info(">> clickonMobileSave - start");
			cbolProfilePrefererencesSanityLocators_Test.mobilesave.click();
			System.out.println("Successmaessge is displayed  " + cbolProfilePrefererencesSanityLocators_Test.success.isDisplayed());
			log.info(">> clickonMobileSave - End");
		}
		
		public void emailSucess()
		{
			
			log.info(">> emailSucess - start");
			System.out.println("Successmessage is displayed  " + cbolProfilePrefererencesSanityLocators_Test.success.isDisplayed());
			log.info(">> emailSucess - End");
		}
		
		
		public void emailError()
		
       {
			
			log.info(">> emailError - start");
			System.out.println("Successmessage is displayed  " + cbolProfilePrefererencesSanityLocators_Test.success.isDisplayed());
			log.info(">> emailError - End");
		}
		
		
		
		
		
}

