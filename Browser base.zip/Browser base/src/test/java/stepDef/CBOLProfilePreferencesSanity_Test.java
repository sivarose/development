package stepDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pageActions.CBOLProfilePreferencesSanityActions_test;
import pageActions.CBOL_CommonActions_test;
import pageActions.CitiHomePageActions_test;
import utils.ConfigFileReader;
import utils.SeleniumDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;



public class CBOLProfilePreferencesSanity_Test {

	private static final String String = null;
	final Log log = LogFactory.getLog(CBOLProfilePreferencesSanity_Test.class.getName());
	CitiHomePageActions_test citiHomePageActions = new CitiHomePageActions_test();
	CBOLProfilePreferencesSanityActions_test cbolProfilePreferencesSanityActions_test = new CBOLProfilePreferencesSanityActions_test();
	CBOL_CommonActions_test cbolCommonActions = new CBOL_CommonActions_test();
	ConfigFileReader configFileReader;
	
	

	@And("^click on Profiles$")
	public void click_on_Profiles(String ag) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.clickOnProfileLink();
		System.setProperty("profile", ag);
	}
	
	@And("^click on contact Info and click on Edit Email$")
	public void click_on_contact_Info_and_click_on_Edit_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.clickOnContactInfo();
		cbolProfilePreferencesSanityActions_test.clickoneditCTA();
	}

	@And("^Update the valid \"([^\"]*)\" and click on save Button$")
	public void Update_the_valid_Email_Id_and_click_on_save_Button(String Email_id) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.enterValueinEmailAddress(Email_id);
		cbolProfilePreferencesSanityActions_test.clickonEmailSave();
		
	}
	
	@And("^Update the valid Mobile \"([^\"]*)\" and click on save Button$")
	public void Update_the_valid_MobileNumber_and_click_on_save_Button(String Email_id) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.clickonmobileeditCTA();
		cbolProfilePreferencesSanityActions_test.enterValueinMobilenumber(Email_id);
		cbolProfilePreferencesSanityActions_test.clickonEmailSave();
		
	}
	
	@Then("^Valid Email Update success message should be displayed$")
	public void Valid_Email_Update_success_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.emailSucess();
	}
	
	@And("^click on contact Info and click on Edit Mobile$")
	public void click_on_contact_Info_and_click_on_Edit_Mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.clickOnContactInfo();
		cbolProfilePreferencesSanityActions_test.clickonmobileeditCTA();
	}

	
	@Then("^Valid Mobile Update success message should be displayed$")
	public void Valid_Mobile_Update_success_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.emailSucess();
	}
	
	@And("^Update the invalid \"([^\"]*)\" and click on save Button$")
	public void Update_the_invalid_Email_Id_and_click_on_save_Button(String Email_id) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.enterValueinEmailAddress(Email_id);
		cbolProfilePreferencesSanityActions_test.clickonEmailSave();
		
	}
	
	@Then("^Error message should be displayed$")
	public void Error_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cbolProfilePreferencesSanityActions_test.emailError();
	}

}
