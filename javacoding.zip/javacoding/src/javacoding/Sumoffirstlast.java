package javacoding;

public class Sumoffirstlast {

	public static void main(String[] args) {
		System.out.println(sumFirstAndLastDigit(257));
	}
	
	public static int sumFirstAndLastDigit(int number)
	{
		int n1;
		if(number<0)
			return -1;
		else
		{
			n1=number%10;
			
			while(number>=10)
			{
				
			number=number/10;
			}
			return n1+number;
						
		}
		
	}
	
}
