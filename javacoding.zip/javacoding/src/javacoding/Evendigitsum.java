package javacoding;

public class Evendigitsum {

	public static void main(String[] args) {
	//	System.out.println(getEvenDigitSum(252));
		
		System.out.println(getEvenNumberDigitSum(252));
	}
	
	public static int getEvenDigitSum(int number)
	{
		int sum=0, count=0,n;
		if(number<0)
			return -1;
		else
		{
			while(number!=0)
			{	
				n=number%10;
				number=number/10;
				count=count+1;
				if(count%2==0)
				{	sum=sum+n;
				System.out.println(sum);
				}
			}		
			return sum;
		}
	}

	public static int getEvenNumberDigitSum(int number)
	{
		int sum=0,n;
		if(number<0)
			return -1;
		else
		{
			while(number!=0)
			{	
				n=number%10;
				number=number/10;
				if(n%2==0)
					sum=sum+n;
			}		
			return sum;
		}
	}

}
