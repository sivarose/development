package javacoding;

public class DecimalComparator {

	public static void main(String[] abc)
	{
		
		boolean dec = areEqualByThreeDecimalPlaces(-3.123, 3.123);
		System.out.println(dec);
	}
	
	public static boolean areEqualByThreeDecimalPlaces(double n1, double n2)
	{
	
	if((int)(n1*1000) == (int)(n2*1000))
	return true;
	else return false;
	}
	
		
}
