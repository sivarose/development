package javacoding;

public class Secondsandminutes {

	
	public static void main(String[] abc)
	{

		System.out.println(getDurationString(65,45));
	System.out.println(getDurationString(3945));
	
	}
	
	public static String getDurationString(int min, int sec)
	{
		if(min<0 || sec<0 || sec>59){
		return "Invalid value";
		}
		else
		{
			
			int hour = min/60;
			int remainingmin = min%60;
			return hour+"h "+remainingmin+" min "+sec+" s";
		
		}	
				
	}
	
	public static String getDurationString(int sec)
	{
		if(sec<0)
		{	
		return "Invalid value";
		}else
		{
			int min=sec/60;
			int remainingsec=sec%60;
			//System.out.println(sec+" seconds is "+min+" min "+remainingsec+" secs");			
			return getDurationString(min,remainingsec);
			
		}
	}
	
	
}
