package javacoding;

public class NumberToWords {

	
	public static void main(String[] args) {
	
	//	numberToWords(100);
		System.out.println(reverse(100));
	//	System.out.println(getDigitCount(100));
	}
	
	public static void numberToWords(int number){
		
		int n;
		if(number<0)
			System.out.println("Invalid value");
		else
		{
			
			while(number!=0)
			{
				n=number%10;
				number=number/10;
				switch(n)
				{
				case 0 :
				System.out.println("Zero");
				break;
				
				case 1 :
					System.out.print("One ");
					break;
				case 2 :
					System.out.print("Two ");
					break;
				case 3 :
					System.out.print("Three ");
					break;
				case 4 :
					System.out.print("Four ");
					break;
				case 5 :
					System.out.print("Five ");
					break;
				case 6 :
					System.out.print("Six ");
					break;
				case 7 :
					System.out.print("Seven ");
					break;
				case 8 :
					System.out.print("Eight ");
					break;
				case 9 :
					System.out.print("Nine ");
					break;
					
				}
				
			}
			
			
		}
		
		
		
		
		
		
	}
	public static int reverse(int number)
	{
		int sum=0, n1, n2=number,revfinal;
		String rev= "";
		
		while(number!=0)
		{
		  n1=number%10;
		  sum=(sum*10)+n1;
		  number=number/10;
		}

		
		if(getDigitCount(n2)==getDigitCount(sum))
   return sum;
	
		else
		{
			 rev= Integer.toString(n2);		
			 System.out.println(rev);
			    String valueReversed = new StringBuilder(rev).reverse().toString();
				 		
			    revfinal = Integer.parseInt(valueReversed);		
			    System.out.println(revfinal);
			    return revfinal;	
		}
			
		}
		
		
	
	
	public static int getDigitCount(int number)
	{
		
		int count=0,n;
		while(number!=0)
		{
		  n=number%10;
		  count++;
		  number=number/10;
		  
		}
		
		return count;
	}
		
	

	
	
}
