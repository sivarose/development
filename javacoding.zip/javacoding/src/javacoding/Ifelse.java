package javacoding;

public class Ifelse {

public static void main(String[] args)
{
	
		int score=100;
		int bonus=500;
		boolean gameover=true;
		
		if(gameover)
		{
			int finalscore = score*bonus;
			System.out.println("Final score is "+finalscore);
		}
		
		score=200;
		bonus=500;
		gameover=false;
		
		if(gameover)
		{
			int finalscore = score*bonus;
			System.out.println("Final score is "+finalscore);
		}
		
		else
		{
			int finalscore = score*bonus+100;
			System.out.println("Final score is "+finalscore);
		
		}
	
}
}

