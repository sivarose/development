package javacoding;

public class While {

	
	public static void main(String[] args) {
	
		
		int abc=0;
	/*	
		while(true)
		{
			if(count==6)
				break;
			System.out.println(count);
			count++;
		}
		
		count=0;		
		while(count!=6)
		{
			System.out.println(count);
			count++;
		}*/
		
		abc=0;
		do{
			System.out.println(abc);
			abc++;
			if(abc>=100)
			{
				break;
			}
		}while(abc!=6);	
	}
}
