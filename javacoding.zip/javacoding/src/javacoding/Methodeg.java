package javacoding;
public class Methodeg {
	public static void main(String[] args)
	{
		int score1= calculateHighScorePosition(1000);
		displayHighScorePosition("Siva",score1);
		int score2 = calculateHighScorePosition(500);
		displayHighScorePosition("Gopal",score2);
		int score3 = calculateHighScorePosition(100);
		displayHighScorePosition("Rose",score3);
		int score4 = calculateHighScorePosition(50);
		displayHighScorePosition("Shavik",score4);
	}	
	public static void displayHighScorePosition(String playername, int position)
	{
		System.out.println(playername+" managed to get into the position "+position+" in the high score table");
	}	
	public static int calculateHighScorePosition(int playerScore)
	{
		/*
		if(playerScore>=1000)
		{
			return 1;
		}
		else if(playerScore>=500 && playerScore<1000)
		{
			return 2;
		}
		else if(playerScore>=100 && playerScore<500)
		{
			return 3;
		}
		else
			return 4;
	}	
	
*/
		int position = 4;
		if(playerScore>=1000)
		{
			position=1;
		}
		else if(playerScore>=500 && playerScore<1000)
		{
			position = 2;
		}
		else if(playerScore>=100 && playerScore<500)
		{
			position = 3;
		}
			return position;
	}	
		
		
}