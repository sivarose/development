package javacoding;

public class Scanner {

	public static void main(String[] args) {
		
		
		
		
		
		
	}
	
}
