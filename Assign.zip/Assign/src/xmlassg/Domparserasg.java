package xmlassg;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Domparserasg {

	
	public static void main(String[] args)throws Exception{		
		
	DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
	
	DocumentBuilder b =df.newDocumentBuilder();

		
	}
	
}
