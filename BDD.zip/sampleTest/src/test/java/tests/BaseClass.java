/**
 * 
 */
package tests;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class BaseClass {
	
	AndroidDriver<AndroidElement> driver;
	
	@BeforeTest
	public AndroidDriver<AndroidElement> setup() {

		File appDir = new File("src/test/resources/apps");
		File app = new File(appDir, "myapkfortest.apk");
		try {

			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Testing");
			capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
			
			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			driver = new AndroidDriver<AndroidElement>(url, capabilities);
			
		} catch (MalformedURLException exp) {
			
			System.out.println("Print the cause: "+ exp.getCause());
			System.out.println("Print the message: "+ exp.getMessage());
			
			exp.printStackTrace();
		}

		return driver;
	}
	
	@AfterTest
	public void tearDown() {
		/*
		 * driver.close(); 
		 * driver.quit();
		 */
	}

}
