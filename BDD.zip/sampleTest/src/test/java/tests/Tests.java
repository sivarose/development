package tests;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class Tests extends BaseClass{

	
@Test
	public void testOne() {
	  
	  AndroidDriver<AndroidElement> driver = setup();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  
		
		System.out.println("my code is correct to proceed");
	}
	

}
