package StepDefination;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import tests.BaseClass;

public class AppiumScenario extends BaseClass{
	
	
	public void testOne() {
	  AndroidDriver<AndroidElement> driver = setup();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	}
	
	@Given("^the application to installed$")
	public void theApplicationToInstalled() throws Throwable{
		testOne();
		
	}
	
	@When("^I launch the application$")
	public void iLaunchTheApplication() throws Throwable{
		System.out.println("Application is already installed and launched");
	}
	
	@Then("^I should able to see application home page$")
	public void iShouldAbleToSeeApplicationHomePage() throws Throwable{
		System.out.println("I should able to see application home page");
		
	}
	
}
