
package test;

import java.net.MalformedURLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.sun.tools.javac.util.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class testProject extends base {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		AndroidDriver<AndroidElement> driver = Mybase();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Identify List of elements using Resource ID 
		List<AndroidElement> allTitleElements = ((AndroidDriver<AndroidElement>) driver)
				.findElementsByAndroidUIAutomator("new UiSelector().resourceId(\"android:id/text1\")");

		System.out.println("Element Count - " + allTitleElements.size());

		for (AndroidElement element : allTitleElements) {
			System.out.println("Text - " + element.getText());
		}

		driver.findElementByAndroidUIAutomator("new UiSelector().resourceId(\"Custom\")").sendKeys("test");
		

		// xpath id className, androidUIautomator
		/*
		 * xpath Syntax //tagName[@attribute='value']
		 * 
		 * 
		 */

		/*
		 * driver.findElementByXPath("//android.widget.TextView[@text='Preference']").
		 * click(); Thread.sleep(2000); driver.
		 * findElementByXPath("//android.widget.TextView[@text='3. Preference dependencies']"
		 * ).click(); driver.findElementById("android:id/checkbox").click();
		 * driver.findElementByXPath("(//android.widget.RelativeLayout)[2]").click();
		 * driver.findElementByClassName("android.widget.EditText").sendKeys("hello");
		 * driver.findElementsByClassName("android.widget.Button").get(1).click();
		 */

	}

}
