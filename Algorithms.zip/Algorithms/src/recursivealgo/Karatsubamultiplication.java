package recursivealgo;

import java.util.Scanner;

public class Karatsubamultiplication {

	public static void multiply(long ac , long ad, long bc, long bd, long digits)
	
	{
	  double mul=0;
	  
	  mul = Math.pow(10, digits) *ac + Math.pow(10, digits/2)*(ad+bc)+bd;
	  
	  System.out.println("The multiplication answer is "+mul);
	}
	
	public static long[] splitnum(long n1) {
		long[] split= new long[3];
		long divider=1;
		long num =0;
		long counter=0;
		num=n1;
		while(num>0) {
			num=num/10;
			counter=counter+1;
		}
		split[2]=counter;
		for(long i=0;i<counter/2;i++) {
			divider*=10;
		}		
		split[0]=n1/divider;
		split[1]=n1%divider;
				
		return split;		
	}
	
	public static void main(String[] args) {
			
		Scanner sc = new Scanner(System.in);	
		System.out.println("Enter value of n1 and n2 ");
		long n1 = sc.nextLong();
		long n2 = sc.nextLong();
		long ac=0,ad=0,bc=0,bd=0,digits=0;
		if(n1/10==0 && n2/10==0)
		{
			System.out.println("The multiplication answer is "+n1*n2);
		}
		else
		{
			long[] a= splitnum(n1);
			long[] c =splitnum(n2);		
			ac = a[0]*c[0];
			ad = a[0]*c[1];
			bc= a[1]*c[0];
			bd= a[1]*c[1];
			digits=a[2];
			multiply(ac,ad,bc,bd,digits);
			
		}
								
	}		
}