package programs;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Panel1 {
	
	
	public static void main(String[] args) {
		
		
		JFrame frame = new JFrame();
		
		JButton button = new JButton("shock me");
		
		JButton button2 = new JButton("bliss");		
		
		JPanel panel = new JPanel();
		
		panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
		
		panel.setBackground(Color.darkGray);
		
		panel.add(button);
		panel.add(button2);

		frame.getContentPane().add(BorderLayout.EAST,panel);		
		frame.setSize(300,300); 
		frame.setVisible(true);

	}

}
