package programs;

import java.util.ArrayList;
import java.util.Comparator;

public class CompareEg implements Comparator {
	
	String a;
	String b;
	String c;
	String d;
	
	CompareEg ce = new CompareEg();

	
	public static void main(String[] args) {
		
		
	}

	public void cmp() {

		ArrayList<CompareEg> al = new ArrayList<CompareEg>();
		al.add(ce);
	}
	
	public String toString() {
		return a;
	}
	
	@Override
	public int compare(Object o1, Object o2) {

		 return 0;
	}

}
