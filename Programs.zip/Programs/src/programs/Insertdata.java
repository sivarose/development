package programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Insertdata {
	
	public static void main(String[] args) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
				
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

		Statement st = con.createStatement();
		
		st.executeUpdate("insert into login values('siva', '12345')");
		
		System.out.println("Login Table value inserted");

	}	

}
