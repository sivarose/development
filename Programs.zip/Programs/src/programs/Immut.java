package programs;

public class Immut {
	
	public static void main(String[] args) {
		
		
		String s = "0";
		
		for(int i=1;i<10;i++) {
		
			s=s+i;
		  		

	}
		
		System.out.println(s);


	}
}
