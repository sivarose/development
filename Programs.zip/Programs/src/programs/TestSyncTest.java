package programs;

public class TestSyncTest {
	
	public static void main(String[] args) {
		
		TestSync job = new TestSync();
		
		Thread a = new Thread(job);
		
		Thread b = new Thread(job);
		
		a.setName("Thread one");
		
		b.setName("Thread two");
		
		a.start();
		
		b.start();
	}

}
   
class TestSync implements Runnable{
	
	private int balance;

	@Override
	public void run() {

		for(int i=0;i<4;i++) {
			increment();
			System.out.println(balance+" is the balance and current thread is "+Thread.currentThread().getName());
		}
		
	}
	
	public synchronized void increment() {
		
		int i = balance;
		
		balance = i+1;
		

		
	}
	
	
}
