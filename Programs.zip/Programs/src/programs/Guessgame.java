package programs;

public class Guessgame {
	
	Players p1;
	Players p2;
	Players p3;
	
	public void startgame()
	{
		
		p1=new Players();
		p2=new Players();
		p3=new Players();
		int guessp1=0;
		int guessp2=0;
		int guessp3=0;
		int randomnumber = 0;		
		System.out.println("I am thinking of a number between 0 and 9...");
		
		boolean p1guess = false;
		boolean p2guess = false;
		boolean p3guess = false;
		
		
		
		while(true)
		{
			randomnumber = (int) (Math.random()*10);	
			
			System.out.println("Number to guess is "+randomnumber);
			
			
			p1.guess();
			p2.guess();
			p3.guess();
			
			
			guessp1=p1.no;
			System.out.println("Player 1 guessed number is "+guessp1);
			
			guessp2=p2.no;
			System.out.println("Player 2 guessed number is "+guessp2);
			
			guessp3=p3.no;
			System.out.println("Player 3 guessed number is "+guessp3);
			
			if(randomnumber==guessp1) {
				p1guess=true;
			}
			if(randomnumber==guessp2) {
				p2guess=true;
			}
			
			if(randomnumber==guessp3) {
				p3guess=true;
			}
			
			if(p1guess==true || p2guess==true || p3guess==true) {
				System.out.println("We have a winner!");
				
				System.out.println("Player 1 got it right: "+p1guess);
				System.out.println("Player 2 got it right: "+p2guess);
				System.out.println("Player 3 got it right: "+p3guess);
				System.out.println("Game is over");
				break;

			}
			else {
				System.out.println("Players will have to try again");
			}
			
		}
		
	}
	
}
