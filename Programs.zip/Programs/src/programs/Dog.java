package programs;

public class Dog extends Animals {

}
