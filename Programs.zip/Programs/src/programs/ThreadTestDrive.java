package programs;

class MyRunnable implements Runnable{

	@Override
	public void run() {

		try {
			go();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void go() throws InterruptedException {
		ThreadTestDrive.myThread.sleep(3000);

		
		doMore();
	}
	
	public void doMore() {
		
		System.out.println("top i' the stack");
	}
	
	

}

public class ThreadTestDrive{
	
	static Thread myThread;
	
	
	public static void main(String[] args) throws InterruptedException {
		
		Runnable threadJob = new MyRunnable();
		
		 myThread = new Thread(threadJob);
		

		
		myThread.start();
		
		
		System.out.println("back in main");
	}
}
