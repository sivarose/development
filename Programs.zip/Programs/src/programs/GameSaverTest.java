package programs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class GameSaverTest {
	
	public static void main(String[] args) {
		
		GameCharacter one = new GameCharacter(50,"Elf",new String[] {"bow","sword","dudt"});
		
		GameCharacter two = new GameCharacter(200,"Troll",new String[] {"bare hands","big ax"});
		
		GameCharacter three = new GameCharacter(120,"Magician",new String[] {"spells","invisibility"});
		
		
		try {
			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("Game.ser"));
			os.writeObject(one);
			os.writeObject(two);
			os.writeObject(three);
			os.close();			
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		one = null;
		two=null;
		three=null;
		
		
		try {
			ObjectInputStream is = new ObjectInputStream(new FileInputStream("Game.ser"));
			GameCharacter oneRestore = (GameCharacter) is.readObject();
			GameCharacter twoRestore = (GameCharacter) is.readObject();
			GameCharacter threeRestore = (GameCharacter) is.readObject();
 			
			
			System.out.println("One's Weapon"+ oneRestore.getWeapons());			
			System.out.println("Two's power"+ twoRestore.getPower());
			System.out.println("Three's type"+ threeRestore.getType());
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}

}
