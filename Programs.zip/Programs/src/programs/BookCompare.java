package programs;

import java.util.Comparator;
import java.util.TreeSet;

public class BookCompare {
	
	public static void main(String[] args) {
		   
		new TestTree().go();
	}
	
	public void go() {
		
		Book b1 =  new Book("How cats Work");
		Book b2 =  new Book("Remiz your body");
		Book b3 =  new Book("Finding Emo");
		
		Book1 book1 = new Book1();
		
		TreeSet<Book> tree = new TreeSet<Book>(book1);
		tree.add(b1);
		tree.add(b2);
		tree.add(b3);
		
		System.out.println(tree);
					
	}

}

class Book1 implements Comparator<Book>{
	
	
	@Override
	public int compare(Book b1, Book b2) {
		
		return b1.title.compareTo(b2.title);
	}

	
	
	
}
