package programs;

import java.io.*;
import java.net.*;

public class DailyAdviceServer {

	public static void main(String[] args) throws Exception {
		
		DailyAdviceServer ad = new DailyAdviceServer();
		
		ad.go();
		
	}
	
	String[] adviceList = { "Take smaller bites", "Just for today be honest", "Go for the tight jeans"};
	
	public void go() throws Exception {
		
		System.out.println("server started");
		
		ServerSocket ss = new ServerSocket(5090);
		
		while(true) {
			
			Socket sock = ss.accept();
			
			PrintWriter pr = new PrintWriter(sock.getOutputStream());
			
			String advice = getAdvice();
			
			pr.println(advice);
			
			pr.close();
			
			System.out.println(advice);
			
		}
		
			
		}
	
	private String getAdvice() {
		
		int random = (int) (Math.random() * adviceList.length);
		return adviceList[random];

	}
	
}
