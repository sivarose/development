package programs;

public class WrapperEg {
	
	
	Integer i;
	int j;
	
	public static void main(String[] args) {
		WrapperEg we = new WrapperEg();
		we.go();
	}
	
	public void go(){	
		
		i=j;
		
		System.out.println(j);
		System.out.println(i);
		
	}

}
