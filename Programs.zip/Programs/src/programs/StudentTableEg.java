package programs;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class StudentTableEg {  

	public static void main(String[] args) throws Exception {
			
	Class.forName("com.mysql.jdbc.Driver");
	
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

	Statement st = con.createStatement();
	
	String sql = "create table login(username varchar(30), password int(10))";
	
	st.execute(sql);
	
	System.out.println("Login Table Created");
		
}		
}