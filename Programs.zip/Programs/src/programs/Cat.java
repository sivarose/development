package programs;

public class Cat extends Animals {

}
