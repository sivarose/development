package programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BatchprocessTransmanage {

	
	public static void main(String[] args)throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

		Statement st = con.createStatement();
		
		con.setAutoCommit(false);
		st.addBatch("update student set name='Ram' where name='Sriram'");		
		st.addBatch("insert into student values('216', 'Sivaranjani', '12', '99.58')");
		
		try {
		st.executeBatch();	
		System.out.println("Batch executed");
		con.commit();
		}
		catch(Exception e) {
			try {
			con.rollback();
			}
			catch(Exception e1) {
				System.out.println(e1);
			}
		}
		con.close();
	}
}
