package programs;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DungeonTest{
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		DungeonGame d = new DungeonGame();
		
		System.out.println(d.getX()+d.getY()+d.getZ());

		FileOutputStream fos = new FileOutputStream("dg.ser");
		 
		ObjectOutputStream os = new ObjectOutputStream(fos);
		
		os.writeObject(d);
		
		os.close();
		
		FileInputStream fis = new FileInputStream("dg.ser");
		
		ObjectInputStream is = new ObjectInputStream(fis); 
		
		d= (DungeonGame) is.readObject();
		
		is.close();
		
		System.out.println(d.getX()+d.getY()+d.getZ());
		
	}
	
}

