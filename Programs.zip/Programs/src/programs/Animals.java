package programs;

public class Animals {
	
	public void eat() {
		
	}

}
