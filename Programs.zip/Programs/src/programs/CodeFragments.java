package programs;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class CodeFragments {
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		panel.setBackground(Color.darkGray);
		JButton button = new JButton("tesuji");
		JButton buttonTwo = new JButton("wateri");
		frame.getContentPane().add(BorderLayout.SOUTH,panel);	
	 	frame.getContentPane().add(BorderLayout.NORTH,button);
		panel.add(buttonTwo);
		frame.setSize(300,300);
		frame.setVisible(true);
			
	}


}
