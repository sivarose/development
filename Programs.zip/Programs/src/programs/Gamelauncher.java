package programs;

public class Gamelauncher {

	public static void main(String[] args) {
		
		Guessgame game = new Guessgame();
		game.startgame();
				
	}
}
