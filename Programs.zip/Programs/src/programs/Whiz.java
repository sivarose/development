package programs;

public class Whiz {
	
	public static void main(String[] a) {
		
		
		int[] b = {1,2,3};
		
		System.out.println(b[3]);
		
	}

}
