package programs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class GuiCompile {
	
	
	public static void main(String[] args) throws IOException {
		
		File f = new File("Ten.txt");
		
		try {
			FileReader fr = new FileReader(f);
			
			BufferedReader br = new BufferedReader(fr);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		FileOutputStream fis = new FileOutputStream("abc.ser");
		try {
			ObjectOutputStream os = new ObjectOutputStream(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("abc.txt"));
		
		
		
		
	}

}
