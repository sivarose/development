package programs;

import java.util.ArrayList;
import java.util.List;

public class TestGenerics1 {
	
	public static void main(String[] args) {
		
	}
	
	/*
	 * public void go() {
	 * 
	 * Animals[] animals = {new Dog() , new Cat(), new Dog()};
	 * 
	 * Dog[] dogs = {new Dog(), new Dog(),new Dog()};
	 * 
	 * takeAnimals(animals);
	 * 
	 * takeAnimals(dogs);
	 * 
	 * }
	 * 
	 * public void takeAnimals(Animals[] animals) {
	 * 
	 * for(Animals a: animals) {
	 * 
	 * a.eat();
	 * 
	 * }
	 * 
	 * }
	 */
	
	
	public void go() {
		
		ArrayList<Dog> animals1 = new ArrayList<Dog>();
		
		List<Animals> list = new ArrayList<Animals>();
		
		
		
		ArrayList<Dog> dogs = new ArrayList<Dog>();
		
		
		List<Dog> dogList = dogs;
		
		ArrayList<Object> objects = new ArrayList<Object>();
		
		List<Object> objList = objects; 
		
		
		
	}
}
