package programs;

public class Players {
	
	int no=0;
	
	public void guess()
	{
		no= (int) (Math.random() *10);
		System.out.println("I am guessing "+no);
	}
	

}
