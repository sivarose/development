package programs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class DungeonGame implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int x=3;
	transient long y=4;
	private short z=5;
	
	int getX() {
		return x;
	}
	
	long getY() {
		
		return y;
	}
	 
	
	short getZ() {
		
		return z;
	}
}
