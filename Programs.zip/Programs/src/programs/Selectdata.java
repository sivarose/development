package programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Selectdata {

	public static void main(String[] args)throws Exception {		
		
		Class.forName("com.mysql.jdbc.Driver");
			
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

		Statement st = con.createStatement();
							
		ResultSet rs = 	st.executeQuery("select * from login");
		
	//	System.out.println("ID   Name  Class  Marks");
		
		System.out.println("UserName Password");

		while(rs.next()) {
			System.out.print(rs.getString(1)+" ");
			System.out.print(rs.getString(2)+" ");
		//	System.out.print(rs.getString(3)+" ");
		//	System.out.print(rs.getString(4)+" ");
			System.out.println("");

		}
			

	}		
}
