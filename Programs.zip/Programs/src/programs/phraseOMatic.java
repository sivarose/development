package programs;

public class phraseOMatic {

	public static void main(String[] args) {
		
		String[] word1 = {"Siva","Ranjani","Sivaranjani","SivaG","Shiva"};
		String[] word2 = {"is a","will become a"};
		String[] word3 = {"JavaDeveloper","J2EEDeveloper","JavaCoreDeveloper"};
		int word1length = word1.length;
		int word2length = word2.length;
		int word3length = word3.length;
		int rand1 = (int) (Math.random() * word1length);
		int rand2 = (int) (Math.random() * word2length);
		int rand3 = (int) (Math.random() * word3length);
		String word = word1[rand1] + " " + word2[rand2] + " " + word3[rand3];
		
		System.out.println(word);						
	}
		
}
