package programs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class DailyAdviceClient {
	
	public static void main(String[] args) {
		
		DailyAdviceClient da = new DailyAdviceClient();
	
		da.go();
	
	}
	
	public void go(){
		
		try {
			Socket s = new Socket("127.0.0.1",5090);
			
			
			InputStreamReader sr = new InputStreamReader(s.getInputStream());
			
			BufferedReader br = new BufferedReader(sr);
			
			
			String advice = br.readLine();		
			
			System.out.println("Today you should: "+advice);
			
			br.close();
			
		} 
				
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
