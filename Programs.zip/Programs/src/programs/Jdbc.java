package programs;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbc {

	public static void main(String[] args) throws Exception {
		
	
	Class.forName("com.mysql.jdbc.Driver");
	
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

	Statement st = con.createStatement();
	
	String sql = "create table student(Studentid int(5), Name varchar(30), Class int(2), Marks float(10,2))";
	
	st.execute(sql);
	
	System.out.println("Student Table Created");
		
}
	
	
}