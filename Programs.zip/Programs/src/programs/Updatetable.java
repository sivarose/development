package programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Updatetable {

	public static void main(String[] args)throws Exception {
		
	Class.forName("com.mysql.jdbc.Driver");
	
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

	Statement st = con.createStatement();
	
	st.executeUpdate("update student set name='Sriram' where name='Ram'");
	
	System.out.println("Student Table value updated");
	
	}
}
