package programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Deletedata {
	
	public static void main(String[] args)throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/siva","root","");

		Statement st = con.createStatement();
		
		st.executeUpdate("delete from student where Studentid='213'");
		
		System.out.println("Student Table value deleted");
		
		}
}
