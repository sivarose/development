package programs;

public class BeatBoxM {
	
public static void main(String[] args) {
		
		new BeatBox().buildGUI();
	}
	

}
