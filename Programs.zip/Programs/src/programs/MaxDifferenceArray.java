package programs;

public class MaxDifferenceArray {
	
	public static void main(String[] args) {
		
		int[] a = {1,2,5};
		int b;
		
		int maxDifference=Integer.MIN_VALUE;
		
		for(int i=0;i<a.length;i++) {
			
			for(int j=i+1;j<a.length;j++) {
				
				System.out.println(a[i]+" "+a[j]);
				System.out.println("Difference is :"+(a[j]-a[i]));
				b=Math.abs(a[j]-a[i]);
				maxDifference = Integer.max(maxDifference, b);
				System.out.println("Max diff is "+maxDifference); 
			} 
		}
		
	System.out.println("Final max difference is: "+maxDifference);		
		
	}

}
